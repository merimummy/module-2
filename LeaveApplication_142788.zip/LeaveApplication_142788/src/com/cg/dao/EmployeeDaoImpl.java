package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.dto.EmployeeDetails;
import com.cg.dto.EmployeeLeave;

@Repository("employeeDao")
public class EmployeeDaoImpl implements IEmployeeDao 
{
	@PersistenceContext
	EntityManager entitymanager;

	@Override
	public List<EmployeeLeave> getAllLeaveDetails(Long empId) 
	{
		Query query1=entitymanager.createQuery("SELECT emp FROM EmployeeLeave emp where empid=:id");
		query1.setParameter("id", empId);
		List<EmployeeLeave> empList=query1.getResultList();
		return empList;
		
	}

	@Override
	public List<Long> getEmployeeId() 
	{
		Query query2=entitymanager.createQuery("SELECT empId from EmployeeDetails");
		return query2.getResultList();
	}

	@Override
	public String getEmployeeName(Long empId) 
	{
		Query query3=entitymanager.createQuery("SELECT employeeName from EmployeeDetails where empid=:id");
		query3.setParameter("id", empId);
		return (String) query3.getSingleResult();
		
	}

}
