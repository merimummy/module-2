package com.cg.dao;

import java.util.List;

import com.cg.dto.EmployeeDetails;
import com.cg.dto.EmployeeLeave;

public interface IEmployeeDao 
{
	List<EmployeeLeave> getAllLeaveDetails(Long empId);
	public List<Long> getEmployeeId() ;
	public String getEmployeeName(Long empId);
}
