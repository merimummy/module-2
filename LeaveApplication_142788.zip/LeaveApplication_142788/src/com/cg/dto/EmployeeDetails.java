package com.cg.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="employee_details")

public class EmployeeDetails 
{
	@Id
	@Column(name="empid")
	private Long empId;
	@Column(name="ename")
	private String employeeName;
	@Column(name="address")
	private String employeeAddress;
	@Column(name="leaves_avail")
	private Integer leavesAvail;

	public Long getEmpId() {
		return empId;
	}
	public void setEmpId(Long empId) {
		this.empId = empId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getEmployeeAddress() {
		return employeeAddress;
	}
	public void setEmployeeAddress(String employeeAddress) {
		this.employeeAddress = employeeAddress;
	}
	public Integer getLeavesAvail() {
		return leavesAvail;
	}
	public void setLeavesAvail(Integer leavesAvail) {
		this.leavesAvail = leavesAvail;
	}
	@Override
	public String toString() 
	{
		return "EmployeeDetails [empId=" + empId + ", employeeName="
				+ employeeName + ", employeeAddress=" + employeeAddress
				+ ", leavesAvail=" + leavesAvail + "]";
	}


}
