package com.cg.dto.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.dto.EmployeeDetails;
import com.cg.dto.EmployeeLeave;
import com.cg.exception.LeaveAppException;
import com.cg.service.IEmployeeService;



@Controller
public class EmployeeController 
{
	@Autowired
	IEmployeeService employeeservice;

	@RequestMapping(value="homecontrol",method=RequestMethod.GET)
	public String showAppPage(@ModelAttribute("my") EmployeeLeave empleave)
	{
		return "home";
	}

	@RequestMapping(value="ViewLeaveHistory",method=RequestMethod.POST)
	public ModelAndView showLeaveDetails(@ModelAttribute("myy") EmployeeDetails empdetails,Map<String,Object> model)
	{	

		try
		{

			/*if(employeeservice.validateEmployeeId(empdetails.getEmpId()))
			{*/
				System.out.println("data "+empdetails.getEmpId());
				String empName=employeeservice.getEmployeeName(empdetails.getEmpId());
				model.put("empName", empName);
				model.put("empId", empdetails.getEmpId());
				List<EmployeeLeave> emplist=employeeservice.getAllLeaveDetails(empdetails.getEmpId());
				return new ModelAndView("ViewLeaveDetails","temp", emplist);
			//}
			/*else
			{
				return new ModelAndView("home","temp", "Employee ID Does not exist");
			}
*/
		}
		catch(Exception e)
		{
			return new ModelAndView("Error","temp", e.getMessage());
		}

	}
}
