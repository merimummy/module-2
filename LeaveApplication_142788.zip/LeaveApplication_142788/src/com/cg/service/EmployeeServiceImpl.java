package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IEmployeeDao;
import com.cg.dto.EmployeeDetails;
import com.cg.dto.EmployeeLeave;

@Service("employeeservice")
@Transactional
public class EmployeeServiceImpl implements IEmployeeService 
{
	@Autowired
	IEmployeeDao employeeDao;

	@Override
	public List<EmployeeLeave> getAllLeaveDetails(Long empId) {
		
		return employeeDao.getAllLeaveDetails(empId);
	}

	@Override
	public List<Long> getEmployeeId() {
		
		return employeeDao.getEmployeeId();
	}

	@Override
	public String getEmployeeName(Long empId) {
		// TODO Auto-generated method stub
		return employeeDao.getEmployeeName(empId);
	}
	
	public boolean validateEmployeeId(Long empId)
	{
		for(Long empIds :employeeDao.getEmployeeId())
		{
		if(empId.equals(empIds))
				{
					return true;
				}
		}
			return false;
		
		
	}
	
	}
