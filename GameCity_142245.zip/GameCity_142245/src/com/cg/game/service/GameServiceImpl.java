package com.cg.game.service;

import java.util.List;

import com.cg.game.dao.GameDao;
import com.cg.game.dao.GameDaoImpl;
import com.cg.game.dto.GameBean;
import com.cg.game.dto.UserBean;
import com.cg.game.exception.GameException;

public class GameServiceImpl implements GameService
{
    GameDao gd=new GameDaoImpl();
	@Override
	public List<GameBean> getAllGames() throws GameException 
	{
		
		return gd.getAllGames();
	}

	@Override
	public int insertuser(UserBean ub) throws GameException 
	{
		
		return gd.insertuser(ub);
	}

	@Override
	public GameBean getGame(int amount) throws GameException {
		// TODO Auto-generated method stub
		return gd.getGame(amount);
	}
	

}
