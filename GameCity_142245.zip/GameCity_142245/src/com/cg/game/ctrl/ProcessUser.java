package com.cg.game.ctrl;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.game.dto.GameBean;
import com.cg.game.dto.UserBean;
import com.cg.game.exception.GameException;
import com.cg.game.service.GameService;
import com.cg.game.service.GameServiceImpl;



@WebServlet(urlPatterns={"/buycard","/play","/replay"})
public class ProcessUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public ProcessUser() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String url = request.getServletPath();
		String targetUrl ="";
		GameService gs= new GameServiceImpl();
		switch(url)
		{
		case "/buycard":
			UserBean ub=new UserBean();
			ub.setUserName(request.getParameter("cname"));
			ub.setAddress(request.getParameter("add"));
			int amount=Integer.parseInt(request.getParameter("amount"));
			
			
			int netamt=amount-100;
			ub.setCardAmount(netamt);
			try 
			{
				
				List<GameBean> gameList=gs.getAllGames();
				HttpSession sess = request.getSession(true);
				sess.setAttribute("gameList",gameList);
				gs.insertuser(ub);
				sess.setAttribute("user", ub);
				//GameBean gb=new GameBean();
				//sess.setAttribute("game", gb);
				targetUrl="Play.jsp";
				
			}
			catch (GameException e) 
			{
				
				request.setAttribute("error", e.getMessage());
				targetUrl="Error.jsp";
			}
			
			
			break;
			/***************buy card ends here************/
			
		case "/play":
			int gameAmount=Integer.parseInt(request.getParameter("amt"));
			//String gameName=request.getParameter("game");
			try 
			{
				GameBean gb=gs.getGame(gameAmount);
				HttpSession sess = request.getSession(false);
				UserBean ubean=(UserBean)sess.getAttribute("user");
				int balAmt=ubean.getCardAmount();
				sess.setAttribute("game", gb);
				if(balAmt-gameAmount>0)
				{
				int balance=balAmt-gameAmount;
				ubean.setCardAmount(balance);
				targetUrl="Success.jsp";
				}
				else
				{
					targetUrl="Topup.jsp";
				}
			} 
			catch (GameException e) 
			{
				
				request.setAttribute("error", e.getMessage());
				targetUrl="Error.jsp";
			}
			
			
			
			break;
			
			
			/********************play ends here*********************/
		case "/replay":
			targetUrl="Play.jsp";
			break;
		}
		RequestDispatcher disp = request.getRequestDispatcher(targetUrl);
		disp.forward(request, response);
	}

}
