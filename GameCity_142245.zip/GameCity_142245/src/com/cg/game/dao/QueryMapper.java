package com.cg.game.dao;

public interface QueryMapper 
{
	String SELECT_ALL_GAMES="SELECT * FROM ONLINEGAMES";
	String INSERT_QUERY="INSERT INTO USERS Values(?,?,?,?)";
	String SELECT_SEQUENCE="SELECT seq_users.NEXTVAL FROM DUAL";
	String SELECT_Game="SELECT * FROM onlinegames WHERE amount=?";
}
