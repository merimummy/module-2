package com.cg.game.dao;

import java.util.List;

import com.cg.game.dto.GameBean;
import com.cg.game.dto.UserBean;
import com.cg.game.exception.GameException;




public interface GameDao 
{
	List<GameBean>getAllGames()throws GameException;
	int insertuser(UserBean ub)throws GameException;
	GameBean getGame(int amount)throws GameException;
}
