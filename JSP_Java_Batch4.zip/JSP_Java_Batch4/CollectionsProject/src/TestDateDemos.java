import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;


public class TestDateDemos {

	public static void main(String[] args)
	{
		LocalDate today=LocalDate.now();
		System.out.println(" Today date: "+ today);
		
		System.out.println("**********");
		LocalDate myDOJ = LocalDate.of(2010,04,03);
		System.out.println(" my date of joining :"+myDOJ);

		System.out.println("**********");
		String ronalDOJ="13-Dec-2017";
		DateTimeFormatter myFormat=DateTimeFormatter.ofPattern("dd-MMM-yyyy");
		
		LocalDate ronalDojD=LocalDate.parse(ronalDOJ,myFormat);
		System.out.println("Ronal DOJ = "+ronalDojD);
		
		
		System.out.println("****************************");
		
		DateTimeFormatter secondFormat=DateTimeFormatter.ofPattern("yyyy-MMMM-dd");
		

		String urDoj=ronalDojD.format(secondFormat);
		System.out.println(".........." + urDoj);
		////////////////////////////////////
		
		System.out.println("diff");		
		Period period = Period.between(myDOJ, today);
		int years=period.getYears();
		int month=period.getMonths();
		int day=period.getYears();
		
		System.out.println(" my exp in cap is:"+ years+"Years:"+month+"Months :"+day+ "Days");
		
		
		
		
	}

}
