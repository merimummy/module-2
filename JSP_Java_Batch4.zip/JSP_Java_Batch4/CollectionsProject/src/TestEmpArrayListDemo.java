import java.util.ArrayList;
import java.util.Iterator;


public class TestEmpArrayListDemo {

	public static void main(String[] args) 
	{
		ArrayList <Emp> empList = new ArrayList<Emp>();
		Emp e1=new Emp(1333,"vaishali",9000.0F);
		Emp e2=new Emp(2333,"aishali",8000.0F);
		Emp e3=new Emp(3333,"ishali",7000.0F);

		Emp e4=new Emp(4333,"hali",6000.0F);

		Emp e5=new Emp(533,"ali",5000.0F);
		
		
		empList.add(e1);
		empList.add(e2);
		empList.add(e3);
		empList.add(e4);
		empList.add(e5);
		
		
System.out.println("print without iterator");
System.out.println(empList);
System.out.println("print with iterator");

  Iterator<Emp> empListIt=empList.iterator();

 while(empListIt.hasNext())
{
	Emp tempEmp=empListIt.next();
	System.out.println("ID : "+ tempEmp.getEmpId());
	
	System.out.println("Name : "+ tempEmp.getEmpName());
	
	System.out.println("SALARY :"+ tempEmp.getEmpSal());
	
	System.out.println("--------------------");
	
	
	
}



	}

}
