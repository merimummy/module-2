import java.util.*;


public class TestEmpHashSetDemo {

	public static void main(String[] args) 
	{
		HashSet <Emp> empSet = new HashSet<Emp>();
		Emp e1=new Emp(1333,"vaishali",9000.0F);
		Emp e2=new Emp(2333,"aishali",8000.0F);
		Emp e3=new Emp(3333,"ishali",7000.0F);

		Emp e4=new Emp(4333,"hali",6000.0F);

		Emp e5=new Emp(1333,"vaishali",9000.0F);
		
		
		empSet.add(e1);
		empSet.add(e2);
		empSet.add(e3);
		empSet.add(e4);
		empSet.add(e5);
		
		for(Emp tempE:empSet)
		{
			System.out.println(tempE);
		}
	}

}
