import java.util.*;
import java.util.Map.Entry;



public class TestHashMapDemo 
{

	public static void main(String[] args)
	{
	
		HashMap<Long,String> mobileDirectory=new HashMap<Long,String>();
		mobileDirectory.put(2566565656L, "sahil1");
		mobileDirectory.put(2566565656L, "sahil1");
		mobileDirectory.put(3566565656L, "sahil2");
		mobileDirectory.put(4566565656L, "sahil3");
		mobileDirectory.put(5566565656L, "sahil4");
	     Set<Entry<Long,String>> setIt=mobileDirectory.entrySet();
	   //  mobileDirectory.remove(4566565656L);
	     
	//	Iterator<Entry<Long,String>> mobIt =setIt.iterator();
	//	for ( long key : mobileDirectory.keySet() ) {
		//    System.out.println( key );
	//	}
		
		for(String value : mobileDirectory.values() )
		{
			 System.out.println( value );
		}
	// while(mobIt.hasNext())
	 //{
		//Entry<Long,String> dirEntry=mobIt.next();
		// System.out.println("Mobile:" + dirEntry.getKey()+ "Name: "+ dirEntry.getValue());
	 }
	
	
	}


