import java.util.*;


public class TestIntArrayListDemo {

	public static void main(String[] args) 
	{
	
		ArrayList<Integer> intList= new ArrayList<Integer>();
		Integer i1=new Integer(10);  /////////boxing converting primitive datatype to object
 		Integer i2=new Integer(20);
		Integer i3=new Integer(60);
		Integer i4=new Integer(80);
		Integer i5=new Integer(78);
		
		
		intList.add(i1);
		intList.add(i2);
		intList.add(i3);
		intList.add(i4);
		intList.add(i5);
		System.out.println(" without iterator");
		System.out.println(intList);
		
		
		
		System.out.println("with iterrator");
		
		
	Iterator it=intList.iterator();
	
	while(it.hasNext())
	{
		System.out.println(" : "+it.next());
	}
		
	}

}
