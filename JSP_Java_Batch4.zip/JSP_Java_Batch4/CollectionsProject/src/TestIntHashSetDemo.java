import java.util.*;


public class TestIntHashSetDemo
{

	public static void main(String[] args) 
	{
		HashSet<Integer> intSet=new HashSet<Integer>();
		
		
	}	
}
		
		
	