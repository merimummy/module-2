
public class TestDrawingApp {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub

		Shape shape1=new Circle(5);
		Shape shape2=new Circle(2);
		Shape shape3=new Circle(5);
		
		
		System.out.println("Area of shape1 is: " +shape1.calcArea());
		System.out.println(" Area of shape2 is: " +shape2.calcArea());
		System.out.println("Area of shape3 is: "+shape3.calcArea());
		
		System.out.println("Perimeter of shape1 is: " +shape1.calcPerimeter());
		System.out.println("Perimeter of shape2 is :" +shape2.calcPerimeter());
		System.out.println("Perimeter of shape3 is :" +shape3.calcPerimeter());
		
		
	}

}
