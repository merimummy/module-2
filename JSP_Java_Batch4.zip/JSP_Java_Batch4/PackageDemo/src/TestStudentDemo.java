import com.cg.bat.Batch;
import com.cg.stu.Student;
public class TestStudentDemo {

	public static void main(String[] args)
	{
	Batch javaBatch=new Batch("JEE_PROPEL_001", "8.30 TO 6.00","Anjulata ");
	
	Batch vnvBatch=new Batch("VNV_PROPEL_001", "9.30 TO 12.00","SHILPA ");

	Batch oraAppBatch=new Batch("OraApp_PROPEL_001", "12.30 TO 3.00","sachin ");
	
	
	Student student1=new Student(111,"Ronak",90,javaBatch);
	Student student2=new Student(222,"Ravi",40,vnvBatch);
	Student student3=new Student(333,"Rinki",60,oraAppBatch);
	Student student4=new Student(444,"pinku",80,vnvBatch);
	
	
	
	System.out.println(student1.dispStuInfo());
	System.out.println(student2.dispStuInfo());
	System.out.println(student3.dispStuInfo());
	System.out.println(student4.dispStuInfo());
	
	
	
	
	}

}
