import java.util.Scanner;


public class TestBankAppDemo {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
      Scanner sc= new Scanner(System.in);
      int currentBalance=6000;
      System.out.println("" + "Enter the withdraw Amount");
      int withdrawlAmt= sc.nextInt();
      if(withdrawlAmt<currentBalance)
      {
    	  System.out.println("OK U HAVE"+ "SUFFIENT BALA U CAN" + "withdraw");
      }
      else
      {
    	  try {
    	  throw new LowBalanceException 
    	  ("please chk balance");
      }
       catch(LowBalanceException ex)
      {
    	  System.out.println("insufficent balance" +ex.getMessage());
    	  
      }
      
      
      
      }
	}

	}
