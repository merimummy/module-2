import java.io.IOException;

public class ThrowsDemo
{
public void method1() throws IOException
{
	
System.out.println(" inside method 1");	
method2();
}

public void method2() throws IOException
{
	System.out.println(" inside method2");
	
		throw new IOException();
	
}

}



