import static java.lang.Math.*; 

class parent
{
public 	void print()
	{
		System.out.println("Parent :");
    }
///////////////// var args/////////////////////
public int add( int ...numbers)
{
	
	int sum=0;
	for(int j=0;j<numbers.length;j++)
	{
		sum=sum+numbers[j];
	}
	return sum;
}

}

class Child extends parent
{
	@Override
	public void print()
	{
		System.out.println("Child :");
	}
	
}

public class TestJava5FeaturesDemo 
{
    
	public static void main(String[] args) 
	{
		parent pp=new parent();
		System.out.println("Addition of 2  is:" + pp.add(88, 90));
		System.out.println("Addition of 3  is:" + pp.add(9,80,90));
		
		
		System.out.println("PI = "+PI);	
		System.out.println("cube of 2 = "+ pow(2,3));
		
		
	/////////////////enhance for loop //////////////////////	
		System.out.println("Enhance for loop");
		int marks[]=new int[3];
		marks[0]=390;
		marks[1]=290;
		marks[2]=190;
		String cityList[]={"pune" ,"mumbai","noida"};
		
		
		for( int tempMarks:marks)
		{
			System.out.println("" + tempMarks);
		}
		
		for(String city:cityList)
		{
			System.out.println("" + city);
		}
		
		
		
		
		
		
	}

}
