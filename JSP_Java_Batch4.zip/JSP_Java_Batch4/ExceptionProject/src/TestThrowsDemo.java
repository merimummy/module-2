import java.io.IOException;


public class TestThrowsDemo {

	public static void main(String[] args) 
	{
		
		ThrowsDemo tt=new ThrowsDemo();
		try 
		{
			tt.method1();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			
			e.printStackTrace();
			System.out.println("IO ExCEPTION" +"coming in et1");
		}
	}

}
