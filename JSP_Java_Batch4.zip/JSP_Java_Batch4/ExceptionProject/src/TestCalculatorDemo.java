import java.time.LocalDate;
import java.util.*;
class Calculator
{
	int num1;
	int num2;
	int nums[]=new int[2];
	public Calculator(){}
	public Calculator (int num1,int num2)
	{
		this.num1=num1;
		this.num2=num2;
		nums[0]=num1;
		nums[1]=num2;
	}
	public float doDivision() 
	{
		float result=0.0f;
		
		try
		{
		/*	System.out.println("3 rd loaction of" + "Nums" + " is "+nums[3]); */
			
		 result=nums[0]/nums[1];
		}
		catch(ArithmeticException ae)
		{
			
			System.out.println("please check the divisor");
			ae.getMessage();
		}
		
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		
		finally
		{
			
			System.out.println("this block will work");
			
		}
			
		
		return (int)  result;
		
	}
}

public class TestCalculatorDemo {

	public static void main(String[] args) 
	
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter num1 : ");
		int num1=sc.nextInt();
		
		System.out.println("enter num2 : ");
		int num2=sc.nextInt();
		
		Calculator cc=new Calculator(num1,num2);
		System.out.println("Division of 2 number is: " + cc.doDivision());
 		cc.doDivision();
        LocalDate today=null;
        System.out.println("Today is : "+ LocalDate.now());

	}

}
