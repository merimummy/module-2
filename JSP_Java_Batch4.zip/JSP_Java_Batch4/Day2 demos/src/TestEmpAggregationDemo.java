import java.util.*;
public class TestEmpAggregationDemo {

	public static void main(String[] args) 
	{
	 Scanner sc= new Scanner(System.in);
	 System.out.println("Enter the no of employees");
	 int noOfEmployees = sc.nextInt();
	 Employee employeeinfo []= new Employee[noOfEmployees];
	 Date d1[]= new Date[noOfEmployees];
	 
	    int empid=0; int empSal=0; 
		String empName;
		int d=0,m=0,y=0;
		
		for(int i=0;i<employeeinfo.length;i++)
		{
			System.out.println("Enter EMPLOYEEID");
			 empid=sc.nextInt();
			    	
			 System.out.println("Enter EMPLOYEENAME");
			 empName=sc.next();
			    	
			 System.out.println("Enter EMPLOYEESAL");
			 empSal=sc.nextInt();
			 
			 System.out.println("Enter Day of your Joining");
			 d=sc.nextInt();
			 
			 System.out.println("Enter Month of your joining :");
			 m=sc.nextInt();
			 
			 System.out.println("Enter Year of your Joining :");
			 y=sc.nextInt();
			 
			 d1[i]=new Date(d,m,y);
			 employeeinfo[i]=new Employee(empid,empName,empSal,d1[i]);
			 
			
		}
		
		 for( int j=0;j<employeeinfo.length;j++)
		 {  
			 System.out.println(employeeinfo[j].dispEmpInfo());
		 }
     
     
	}

}
