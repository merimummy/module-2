import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;


public class TestPropertyFileDemo {

	public static void main(String[] args)
	
	{
		FileReader fr=null;
		Properties props=null;
		
		try 
		{
			 fr=new FileReader("userInfo.properties");
			 props=new Properties();
			 props.load(fr);
			 System.out.println("********all data*********" + props.size());
			 
			 for(int j=0;j<props.size();j++)
			 {
				String unm=props.getProperty("username");
				String pwd=props.getProperty("password");
				String location=props.getProperty("loaction");
				String state=props.getProperty("state");
				System.out.println(" user info : "+ unm+ "" +pwd + " location "+" "+state);
				 
				 
			 }
			 
		} 
		catch (IOException e)
		{
			
			e.printStackTrace();
		}
		
		

	}

}
