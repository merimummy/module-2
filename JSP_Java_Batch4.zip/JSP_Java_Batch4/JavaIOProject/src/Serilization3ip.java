    import java.io.FileNotFoundException;
    import java.io.FileOutputStream;
    import java.io.IOException;
    import java.io.ObjectOutputStream;
    import java.util.Scanner;

public class Serilization3ip {


        public static void main(String[] args) 
        {
            Scanner sc=new Scanner(System.in);
            Emp e[]=new Emp[3];
        for(int i=0;i<3;i++)
        {
            System.out.println("Enter Emp Id : ");
            int empId=sc.nextInt();
            
            System.out.println("Enter Emp Name: ");
            String empName=sc.next();
            
            System.out.println("Enter Emp Salary: ");
            float empSal=sc.nextFloat();
            
            e[i]=new Emp(empId,empName,empSal);
        }   
            FileOutputStream fos;
            
            try {
                fos=new FileOutputStream("EmpData.obj");
                ObjectOutputStream oos=new ObjectOutputStream(fos);
                for(int i=0;i<3;i++){
                oos.writeObject(e[i]);
                }
                
            } catch (IOException ee) {
                
                ee.printStackTrace();
            }
            System.out.println("Emp Object is Written in a File");
        }
        
    
}
