import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;


public class TestReaderDemo {

	public static void main(String[] args) 
	{
		FileReader fr=null;
		FileWriter fw=null;
		BufferedReader br=null;
		BufferedWriter bw=null;
		
		
		try
		{
	      fr=new FileReader("MyDate.java");
	      br =new BufferedReader(fr); 
	      fw=new FileWriter("Vaishali.txt");
	      bw=new BufferedWriter(fw);
	      String line=br.readLine();
	      while(line!=null)
	      {
	    	  bw.write(line);
	    	  bw.newLine();
	    	  bw.flush();
	    	   line=br.readLine();
	      }
	      
	      System.out.println(" ALL DATA WRITTEN" + "LINE BY LINE IN THE FILE");
	      
	      
		} 
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
