
public class TestPersonDetails1
{

	public static void main(String [] args)
	{
		PersonDetails1 s1= new PersonDetails1();
		System.out.println("Person Details");
		
		System.out.println("----------");
		
		
		s1.setFirstName("Divya");
		s1.setLastName("Bharathi");
		s1.setgender('F');
		s1.setage(20);
		s1.setWeight(85.55);
		System.out.println("First Name: "+s1.getFirstName());
		System.out.println("Last Name:"+s1.getLastName());
		System.out.println("Gender:"+ s1.getgender());
		System.out.println("Age: "+s1.getage());
		System.out.println("Weight:"+s1.getWeight());
		

		
	}
}
