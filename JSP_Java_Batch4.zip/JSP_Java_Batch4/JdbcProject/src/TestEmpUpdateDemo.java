import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;


public class TestEmpUpdateDemo {

	public static void main(String[] args)
	{
		Connection con=null;
		Scanner sc=null;
		PreparedStatement pst;
		try
		{
			sc = new Scanner(System.in);
	    
	    Class.forName("oracle.jdbc.driver.OracleDriver");
	    con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123"); 
	    
	    System.out.println(" enter the empid to be updated");
	    int emp_id=sc.nextInt();
	 String updateQry=" update emp_142791 set emp_salary = emp_salary+1000 where emp_salary<220000";
	    pst=con.prepareStatement(updateQry);
	 
	      pst.executeUpdate();
	    
	    System.out.println(" updated");
			   
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		

	
	}
		
	}


