import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;


public class TestEmpAddDemo {

	public static void main(String[] args) 
	{
		
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		try
		{
	    
	    Class.forName("oracle.jdbc.driver.OracleDriver");
	    con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");  
		st=con.createStatement();	
		String insertQry= "insert into  emp_142791 ("+ "emp_id,emp_name,emp_salary)"
				+ "values(666,'kavita',60000) ";
		
		st=con.createStatement();
		int data=st.executeUpdate(insertQry);
		System.out.println(" data inserted in table:"+ data);
		
	}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		

}
}
