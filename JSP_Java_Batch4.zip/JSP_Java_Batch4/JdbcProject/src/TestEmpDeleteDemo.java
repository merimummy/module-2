import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;


public class TestEmpDeleteDemo {

	public static void main(String[] args)
	{
		Connection con=null;
		Scanner sc=null;
		PreparedStatement pst;
		try
		{
			sc = new Scanner(System.in);
	    
	    Class.forName("oracle.jdbc.driver.OracleDriver");
	    con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123"); 
	    
	    System.out.println(" enter the empid to be deleted");
	    int emp_id=sc.nextInt();
	    String deleteQry=" delete from emp_142791 where emp_id = ?";
	    pst=con.prepareStatement(deleteQry);
	    pst.setInt(1,emp_id);
	    
	    int data=pst.executeUpdate();
	    
	    System.out.println(" data delected");
			   
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		

	
	}
	

	}


