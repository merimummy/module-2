import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;


public class TestEmpData3Demo 
{

	public static void main(String[] args)
	{

		Connection con=null;
		Scanner sc=null;
		PreparedStatement pst;
		try
		{
			sc = new Scanner(System.in);
	    
	    Class.forName("oracle.jdbc.driver.OracleDriver");
	    con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123"); 
	    
	    System.out.println(" enter no of records");
	    int rec=sc.nextInt();
	    String insertQry="INSERT INTO emp_142791(emp_id," + "emp_name, emp_salary)values"
	    		+ "(?,?,?)";
	    pst=con.prepareStatement(insertQry);
			    for(int i=0;i<rec;i++)
			    {
				    System.out.println(" enter id");
					int empId=sc.nextInt();
					
					System.out.println(" enter name");
					String empName=sc.next();
					
					
					System.out.println(" enter salary");
					float empSal=sc.nextFloat();
				        
			
					pst.setInt(1,empId);
					pst.setString(2,empName);
					pst.setFloat(3, empSal);
					int dataAdded=pst.executeUpdate();
					System.out.println(" data is added");
	    
			    }
		
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		

	
	}
	}
