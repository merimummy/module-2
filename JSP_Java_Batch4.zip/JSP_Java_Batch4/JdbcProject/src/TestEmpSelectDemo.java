import java.sql.*;
public class TestEmpSelectDemo {

	public static void main(String[] args)
	
	{
		//load oracle type 4 in memory
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		try
		{
	Class.forName("oracle.jdbc.driver.OracleDriver");
	con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");  
		st=con.createStatement();	
		String selQry= "Select emp_id,emp_name,emp_salary from emp_142791";
		
		rs=st.executeQuery(selQry);
		System.out.println(" ID \t NAME \t  SALARY");
		
		while(rs.next())
		{
		
		System.out.println(rs.getInt("emp_id") + "\t  "+rs.getString("emp_name") +
				"\t "+rs.getInt("emp_salary"));
		
		}
	    }
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
		
		

	}

}
