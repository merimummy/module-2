
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.Scanner;


public class TestResultMetaDataDemo {

	public static void main(String[] args)
	{
		
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		ResultSetMetaData rsmd=null;
		try
		{
		
	    
	    Class.forName("oracle.jdbc.driver.OracleDriver");
	    con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123"); 
	    
	    st=con.createStatement();
	    rs=st.executeQuery("Select * from " +"emp_142791");
	    
	    rsmd=rs.getMetaData();
	    int columnCount=rsmd.getColumnCount();
	    
	    System.out.println(" no of coloumns: "+ columnCount);
	    
	    for( int i=1;i<columnCount;i++)
	    {
	    	
	    	 System.out.println(i+"Column name:" + rsmd.getColumnName(i));
	    	 System.out.println(i+ "Column Type:" +rsmd.getColumnName(i));
	    	 System.out.println(i+  "Column type name:"+ rsmd.getColumnName(i));
	    	 System.out.println(i+ "Column Label:"+ rsmd.getColumnName(i));
	    	 System.out.println("*************");
	    }
	    
	   
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		

	
	}
	
		
		
	}


