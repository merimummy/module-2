import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;


public class TestEmpMainuDemo {

	public static void main(String[] args)
	{
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		PreparedStatement pst;
		try
		{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");  	
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the no of records ");
		
		System.out.println();
		
		int choice=sc.nextInt();
		System.out.println(" enter the choice");
		
		switch(choice)
		{
		
		case 1:

		    System.out.println(" enter the empid to be updated");
		    int emp_id=sc.nextInt();
		 String updateQry=" update emp_142791 set emp_salary = emp_salary+1000 where emp_salary<220000";
		    pst=con.prepareStatement(updateQry);
		 
		      pst.executeUpdate();
		    
		    System.out.println(" updated");
			
		    
		case 2:
			
			System.out.println(" enter the empid to be deleted");
		    int emp_id1=sc.nextInt();
		    String deleteQry=" delete from emp_142791 where emp_id = ?";
		    pst=con.prepareStatement(deleteQry);
		    pst.setInt(1,emp_id1);
		    
		    int data=pst.executeUpdate();
		    
		    System.out.println(" data delected");
				   
			}
    
		}
		
	    catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
		

	}

}
