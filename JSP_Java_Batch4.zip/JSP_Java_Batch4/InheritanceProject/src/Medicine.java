
public class Medicine 
{
private String mName;
private String comName;
private String expDate;
private int price;

public Medicine()
{
	}

public Medicine(String mName, String comName, String expDate, int price) {

	this.mName = mName;
	this.comName = comName;
	this.expDate = expDate;
	this.price = price;
}


public String dispMedInfo() {
	return "Medicine [mName=" + mName + ", comName=" + comName + ", expDate="
			+ expDate + ", price=" + price + "]";
}



}
