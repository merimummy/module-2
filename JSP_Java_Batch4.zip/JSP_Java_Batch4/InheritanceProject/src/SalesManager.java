
public class SalesManager extends WageEmp
{
private float comm;
private int Sales;
public SalesManager()
{
super();		
}
public SalesManager(int empId, String empName, float empSal, int noOfHrs, int ratePerHrs, int Sales, float comm)
{
	super(empId, empName, empSal, noOfHrs,ratePerHrs);
	 this.Sales=Sales;
	 this.comm=comm;
}

public float calcEmpBasicSal()
{
	return super.calcEmpBasicSal() + ((Sales*comm));
}
public float calcEmpAnnualSal()
{
	return calcEmpBasicSal()*12;
			
}	


}
