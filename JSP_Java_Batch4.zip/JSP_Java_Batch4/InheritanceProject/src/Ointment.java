
public class Ointment extends Medicine 
{
	public Ointment()
	{
		super();
	}
	
	public Ointment( String mName, String comName, String expDate, int price)
	{
		super(mName,comName,expDate,price);
	}
	
	public String disMedInfo() {
		return super.dispMedInfo() +"for external use";
	}
	
	
	
	
	
	
	
}
