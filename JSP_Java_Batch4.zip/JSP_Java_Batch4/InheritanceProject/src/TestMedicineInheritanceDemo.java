import java.util.Scanner;


public class TestMedicineInheritanceDemo
{
public static void main(String []args)
{
	Scanner sc=new Scanner(System.in);
	   System.out.println(" HOW MANY MEDICINES");
	     int medCount=sc.nextInt();
	     Medicine medArr[]=new Medicine [medCount];
	     String mName=null;
	     String cName=null;
	    String eDate=null;
	    int prz=0;
	     for(int i=0;i<medArr.length;i++)
	     {
	    	 System.out.println("enter the medicine name");
	    	 mName=sc.next();
	    	 System.out.println(" enter the company name");
	    	  cName=sc.next();
	    	 System.out.println("enter the expiry date");
	    	 eDate=sc.next();
	    	 System.out.println(" enter the price ");
	    	 prz=sc.nextInt();
	    	 System.out.println("what type of medicine "+mName +"Is ?" + "1:Tablet\t2:Syrup\t 3:Ointment");
	    	 
	    	 
	    	 System.out.println("Enter choice");
	    	 int choice=sc.nextInt();
	    	 switch(choice)
	    	 {
	    	 case 1:medArr[i]=new Tablet(mName,cName,eDate,prz);
	    	 break;
	    	 case 2:medArr[i]=new Ointment(mName,cName,eDate,prz);
	    	 default:
	    	 medArr[i]=new Syrup(mName,cName,eDate,prz);
	    	 }
	     }
	    	
	     System.out.println("**********");
	     for(int j=0;j<medArr.length;j++)
	     {
	      if(medArr[j] instanceof Syrup)
	      {
	    	  System.out.println("Syrup :" + medArr[j].dispMedInfo()); 
	      }
	      else if(medArr[j] instanceof Tablet)
	      {
	    	  System.out.println("Tablet :"+medArr[j].dispMedInfo());
	      }
	      else if(medArr[j] instanceof Ointment)
	      {
	    	  
	    	  System.out.println("OintMent"+ medArr[j].dispMedInfo());  
	    			     
	      }
	        
	      
	      }
	     }
		

	    	 
}

