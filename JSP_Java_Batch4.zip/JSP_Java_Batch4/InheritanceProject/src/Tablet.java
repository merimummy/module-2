
public class Tablet extends Medicine
{
public Tablet()
{
	super();
}
public Tablet(  String mName, String comName, String expDate, int price)
{
super(mName,comName,expDate,price);
}

public String disMedInfo() {
	return super.dispMedInfo() + " dont eat tablet too much";
}




}
