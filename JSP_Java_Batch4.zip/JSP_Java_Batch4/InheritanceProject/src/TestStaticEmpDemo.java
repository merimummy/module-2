
public class TestStaticEmpDemo
{
	public static void func()
	{
		System.out.println(" method");
	}
	static
	{
		System.out.println("this is testStatic block ");
	}
	
	
	
public static void main(String[] args)
{
	func();
	System.out.println("main method");
 Emp e1=new Emp(111,"Vaishali",1000.0F);
 Emp e2=new Emp(222,"rohan",4000.0F);
 Emp e3=new Emp(333,"sahil",5000.0F);
 System.out.println(e1.dispEmpInfo());
 System.out.println(e2.dispEmpInfo());
 System.out.println(e3.dispEmpInfo());
 Emp.getCount();
}
}

