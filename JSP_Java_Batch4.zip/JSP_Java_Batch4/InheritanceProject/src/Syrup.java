
public class Syrup extends Medicine 
{
public Syrup()
{
	super();
}
	public Syrup( String mName, String comName, String expDate, int price)
	{
		super(mName,comName,expDate,price);
	}
	
	public String disMedInfo() {
		return super.dispMedInfo() +"shake well before use";
	}
	
	
	
}
