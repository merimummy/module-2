class Calculator
{
	public void add(int a ,int b)
	{
		System.out.println("Addition of 2 int:" + (a+b));
	}
	public void add(int a ,int b, int c)
	{
		System.out.println("Addition of 3 int:" + (a+b+c));
	}
	public void add(float a ,float b)
	{
		System.out.println("Addition of 2 float:" + (a+b));
	}
	public void add(byte a ,byte b)
	{
		System.out.println("Addition of 2 byte:" + (a+b));
	}
	public void add(Integer a ,Integer b)
	{
		System.out.println("Addition of 2 int wrapper class:" + (a+b));
	}
}
public class TestCalculatorDemo 
{
public static void main(String [] args)
{
	Calculator calc=new Calculator();
	calc.add(10,20);
	calc.add(10, 20,30);
	calc.add((byte)10,(byte)20);
	calc.add(10.0F,20.0F);
	calc.add(new Integer(10), new Integer(20));
	Integer i1=new Integer(10);// passing reference i1 to calc.add i1 is passed as the reference.
	calc.add(i1,new Integer(20));
	System.out.println(i1.toString());
	
	
}
}
