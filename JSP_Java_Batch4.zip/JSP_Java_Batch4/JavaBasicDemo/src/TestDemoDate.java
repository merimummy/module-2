
public class TestDemoDate {

	public static void main(String[] args)
	
	{
		Date roshanDOJ=null;
        roshanDOJ = new Date(13,12,2017);
        System.out.println("Roshan DOJ IS: "+
        roshanDOJ.dispDate());
        
        Date vaiDoj=new Date(04,03,2017);
        System.out.println("Vaishali DOJ IS: "+
                vaiDoj.dispDate());
        
        
        Date unknownPerson=new Date();
        System.out.println("Unknown person IS: "+
                unknownPerson.dispDate());       
	}
}
