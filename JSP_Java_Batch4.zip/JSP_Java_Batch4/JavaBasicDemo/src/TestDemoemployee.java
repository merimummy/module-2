class TestDemoemployee{
public static void main(String [] args)

{

 Employee Vaishali= new Employee(1,"sahil",2999, 'M');
 Employee Vaishali1= new Employee(2,"ROSHAN",12999, 'M');
 Employee Vaishali2= new Employee(3,"CHANDI",32999, 'F');
 Vaishali.Display();
 Vaishali1.Display();
 Vaishali2.Display();
	
}
}
