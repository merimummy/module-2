import java.util.*;;
public class DateScannerDemo 
{
public static void main(String [] args)
{
	Scanner sc= new Scanner(System.in);
	
	       System.out.println("Enter Day :");
	        int dayOfDoj=sc.nextInt();
	        
	        
	        System.out.println("Enter month :");
	        int monOfDoj=sc.nextInt();
	        
	        
	        
	        
	        System.out.println("Enter year :");
	        int yearOfDoj=sc.nextInt();
	        
	        Date roshanDOJ=new Date(dayOfDoj,monOfDoj,yearOfDoj);
	        
	        System.out.println("UR DOJ : "+ roshanDOJ.dispDate());
	        
	        
	 ////////////////////////////////////////////////////////////////////////////////////    
           
	        System.out.println("Enter Day :");
	        int dayOfDoj1=sc.nextInt();
	        
	        
	        System.out.println("Enter month :");
	        int monOfDoj1=sc.nextInt();
	        
	        
	        
	        
	        System.out.println("Enter year :");
	        int yearOfDoj1=sc.nextInt();
	        
	        Date roshanDOJ1=new Date(dayOfDoj1,monOfDoj1,yearOfDoj1);
	        
	        System.out.println("UR DOJ : "+ roshanDOJ1.dispDate());
	        
	        
	        
	        
	        
	        
}
}
