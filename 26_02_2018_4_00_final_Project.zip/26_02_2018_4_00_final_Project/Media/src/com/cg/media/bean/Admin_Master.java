package com.cg.media.bean;

public class Admin_Master 
{
	private int adminId;
	private String adminPwd;
	public int getAdminId() {
		return adminId;
	}
	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}
	public String getAdminPwd() {
		return adminPwd;
	}
	public void setAdminPwd(String adminPwd) {
		this.adminPwd = adminPwd;
	}
	public Admin_Master() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Admin_Master(int adminId, String adminPwd) {
		super();
		this.adminId = adminId;
		this.adminPwd = adminPwd;
	}
	
	
}
