package com.cg.media.ui;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.naming.spi.DirStateFactory.Result;

import com.cg.media.bean.Artist_Master;
import com.cg.media.bean.Artist_Song_Assoc;
import com.cg.media.bean.Composer_Master;
import com.cg.media.bean.Composer_Song_Assoc;
import com.cg.media.bean.Song_Master;
import com.cg.media.exception.MediaException;
import com.cg.media.service.MediaService;
import com.cg.media.service.MediaServiceImpl;



public class MediaMain
{
	static Scanner sc=null;
	static MediaService medSer=null;
	static Artist_Song_Assoc artistAssoc=null;
	static Composer_Song_Assoc composerAssoc=null;

	public static void main(String[] args) throws MediaException, SQLException
	{
		medSer= new MediaServiceImpl();
		sc=new Scanner(System.in);




		System.out.println("*************WELCOME TO MEDIA COMPOSER AND ARTIST MANAGEMENT SYSTEM***********");
		System.out.println("Select the type of user you are :");
		System.out.println("\n1. Admin");
		System.out.println("\n2. User");

		int choice1=sc.nextInt();


		switch(choice1)
		{

		case 1://Admin Functionality
			System.out.println("************************************************************");
			System.out.println("                  WELCOME ADMIN                    ");
			System.out.println("************************************************************");
			System.out.println("-------------------------------------");
			System.out.println("Please enter your login credential");
			System.out.println("-------------------------------------");
			System.out.println("Enter Admin Id : ");
			int adminId=sc.nextInt();

			try
			{
				if(medSer.validateAdminId(adminId))	
				{
					System.out.println("-------------------------------------");
					System.out.println("Enter Admin Password");

					String adminPwd=sc.next();
					if(medSer.validateAdminPwd(adminPwd))
					{
						System.out.println("************************************************************");
						System.out.println("         Welcome you are logged in as Admin           ");
						System.out.println("************************************************************");

						while(true)
						{
							System.out.println("************************************************************");
							System.out.println("       Select the operation to perform       ");
							System.out.println("************************************************************");
							System.out.println(" \n \t 1: Add Composer \n  \t 2: Add artist \n \t 3: Find Composer \n  \t 4: Find Artist \n \t 5: Add Song \n \t 6: Update Composer Details \n \t 7: Update Artist Details \n \t 8: Add Song into Artist_Assoc \n \t 9: Add Song into Composer_Assoc \n \t 10: Fetch Details From Artist Assoc \n \t 11: Fetch Details From Composer Assoc \n \tFor Log out press 0");


							int choice=sc.nextInt();
							switch(choice)
							{

							case 1: AddComposer();
							break;

							case 2: AddArtist();
							break;

							case 3: //Find Composer	
								System.out.println("Enter the Composer id: ");
								int compId=sc.nextInt();
								if(medSer.validateComposerId(compId))
								{
									String selectQry="SELECT * from composer_master where composer_id=?";
									Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
									PreparedStatement pst=con.prepareStatement(selectQry);
									pst.setInt(1, compId);
									ResultSet rs=pst.executeQuery();
									rs.next();
									System.out.println("******************************************");
									System.out.println(" The following are the Composer details: ");
									System.out.println("******************************************");
									System.out.println("Composer ID: "+rs.getInt("composer_Id"));
									System.out.println("Composer Name: "+rs.getString("composer_Name"));
									System.out.println("Composer Birth Date: " +rs.getString("composer_Born_Date"));
									System.out.println("Composer Died Date: "+rs.getDate("composer_Died_Date"));
									System.out.println("Composer Caeipi Number: "+rs.getString("composer_Caeipi_Number"));
									System.out.println("Created by: "+rs.getInt("Created_by"));
									System.out.println("Created On: "+rs.getDate("Created_on"));
									System.out.println("Updated by: "+rs.getInt("Updated_by"));
									System.out.println("Updated On: "+rs.getDate("Updated_on"));
								}
								else
								{
									System.err.println("Composer Id not present");
								}
								break;


							case 4://Find Artist
								System.out.println("Enter the Artist id :");
								int artistId=sc.nextInt();
								if(medSer.validateArtistId(artistId))
								{
									String selectQuery="SELECT * from artist_master where artist_id=?";
									Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
									PreparedStatement pst1=conn.prepareStatement(selectQuery);
									pst1.setInt(1, artistId);
									ResultSet rs1=pst1.executeQuery();
									rs1.next();
									System.out.println("******************************************");
									System.out.println(" The following are the artist details: ");
									System.out.println("******************************************");
									System.out.println("Artist ID: "+rs1.getInt("artist_Id"));
									System.out.println("Artist Name: "+rs1.getString("artist_Name"));
									System.out.println("Artist Type: "+rs1.getString("artist_Type"));
									System.out.println("Artist Born Date: "+rs1.getString("artist_Born_Date"));
									System.out.println("Artist Died Date: "+rs1.getDate("artist_Died_Date"));
									System.out.println("Created By: "+rs1.getInt("created_By"));
									System.out.println("Created On: "+rs1.getDate("created_On"));
									System.out.println("Updated By: "+rs1.getInt("updated_By"));
									System.out.println("Updated On: "+rs1.getDate("updated_On"));
								}
								else
								{
									System.err.println("Artist Id Not present");
								}
								break;





							case 5:  AddSongs();
							break;


							case 6: 
								updateComposer();
								break;

							case 7:  
								updateArtist();
								break;

							case 8: addSongInArtistAssoc();
							break;

							case 9: addSongInComposerAssoc();
							break;

							case 10: //Fetch Details from artist song associate
								System.out.println("Enter the Song Id :");
								int songId=sc.nextInt();
								if(medSer.validateArtistSongAssocId(songId))
								{
									String fetchQuery="SELECT * from Artist_Song_Assoc where song_id=?";
									Connection connection=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
									PreparedStatement pst2=connection.prepareStatement(fetchQuery);
									pst2.setInt(1, songId);
									ResultSet rs2=pst2.executeQuery();
									rs2.next();
									System.out.println("******************************************");
									System.out.println(" The following are the details: ");
									System.out.println("******************************************");
									System.out.println("Artist ID: "+rs2.getInt("artist_Id"));
									System.out.println("Artist Name: "+rs2.getString("artist_Name"));
									System.out.println("Song Id: "+rs2.getInt("song_id"));
									System.out.println("Song Name: "+rs2.getString("song_Name"));
									System.out.println("Created By: "+rs2.getInt("Created_by"));
									System.out.println("Created On: "+rs2.getDate("Created_on"));
									System.out.println("Updated By: "+rs2.getInt("Updated_by"));
									System.out.println("Updated On: "+rs2.getDate("Updated_on"));
								}
								else
								{
									System.err.println("Song Id not present");
								}
								break;

							case 11://fetch details from composer song associate
								System.out.println("Enter the Song Id :");
								int songsId=sc.nextInt();
								if(medSer.validateComposerSongAssocId(songsId))
								{
									String Query="SELECT * from Composer_Song_Assoc where song_id=?";
									Connection connection1=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
									PreparedStatement pst3=connection1.prepareStatement(Query);
									pst3.setInt(1, songsId);
									ResultSet rs3=pst3.executeQuery();
									rs3.next();
									System.out.println("******************************************");
									System.out.println(" The following are the details: ");
									System.out.println("******************************************");
									System.out.println("Composer ID: "+rs3.getInt("composer_Id"));
									System.out.println("Composer Name: "+rs3.getString("composer_Name"));
									System.out.println("Song Id: "+rs3.getInt("song_id"));
									System.out.println("Song Name: "+rs3.getString("song_name"));
									System.out.println("Created By: "+rs3.getInt("Created_by"));
									System.out.println("Created On: "+rs3.getDate("Created_on"));
									System.out.println("Updated By: "+rs3.getInt("Updated_by"));
									System.out.println("Updated On: "+rs3.getDate("Updated_on"));
								}
								else
								{
									System.err.println("Song Id not present");
								}
								break;

							default: System.out.println("Thank you Please visit again");
							System.exit(0);   
							}

						}
					}
					else
					{
						System.err.println("Inavlid Admin password");
					}
				}

				else
				{
					System.out.println("Inavlid Admin Id");
				}
			}

			catch(MediaException e)
			{
				System.err.println(e.getMessage());
			}
			break;
			/***********************************************Admin functionality Ends**********************/


		case 2://User Functionality
			System.out.println("************************************************************");
			System.out.println("                  WELCOME USER                 ");
			System.out.println("************************************************************");
			System.out.println("Please Enter Your Login Credentials");
			System.out.println("Enter USER ID : ");
			int userId=sc.nextInt();
			try
			{
				if(medSer.validateUserId(userId))
				{
					System.out.println("Enter USER PASSWORD : ");
					String userPWD=sc.next();
					if(medSer.validateUserPwd(userPWD))
					{
						System.out.println("************************************************************");
						System.out.println("            Welcome you are logged in as user         ");
						System.out.println("************************************************************");
						while(true)
						{	
							System.out.println("********************************");
							System.out.println("Select the operation");
							System.out.println("********************************");

							System.out.println(" \n \t 1: Find Song \n \t 2:Fetch All Songs");

							int choice=sc.nextInt();
							switch(choice)
							{
							case 1: 
								System.out.println("Enter the Song ID :");
								int songId=sc.nextInt();
								if(medSer.validateSongId(songId))
								{
									String selectQuery="SELECT * from song_master where song_id=?";
									Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
									PreparedStatement pst1=conn.prepareStatement(selectQuery);
									pst1.setInt(1, songId);
									ResultSet rs1=pst1.executeQuery();
									rs1.next();
									System.out.println("******************************************");
									System.out.println(" The following are the Song details: ");
									System.out.println("******************************************");
									System.out.println("Song ID: "+rs1.getInt("song_id"));
									System.out.println("Artist ID "+rs1.getInt("artist_id"));
									System.out.println("Song Name: "+rs1.getString("song_name"));
									System.out.println("Song Duration: "+rs1.getString("song_duration")+"mins");
									System.out.println("Created By: "+rs1.getInt("Created_by"));
									System.out.println("Created On: "+rs1.getDate("Created_on"));
									System.out.println("Updated By: "+rs1.getInt("Updated_by"));
									System.out.println("Updated On: "+rs1.getDate("Updated_on"));
								}
								break;

							case 2: fetchAllSongs();
							break;

							default:
								System.out.println("******************************************");
								System.out.println("Thank you Please visit again");
								System.out.println("******************************************");
								System.exit(0);

							}

						}

					}
					else
					{
						System.out.println("Invalid User Password");
					}


				}
				else
				{
					System.out.println("Invalid User Id");
				}
			}
			catch(Exception e)
			{
				System.err.println(e.getMessage());
			}
			break;
			/***********************************************User functionality Ends**********************/
		default:System.out.println("You have selected Invalid option\nThank You Visit Again");
		System.exit(0);
		}
		/***********************************************Switch case ends here**********************/
	}

	/***********************************************Main Ends Here**********************/

	private void FetchDetailsFromComposerAssoc()
	{
		composerAssoc= new Composer_Song_Assoc();
		System.out.println("Enter the Song Id: ");
		int song_id=sc.nextInt();

		System.out.println("song_id"+song_id);

		try
		{
			medSer.getAllInfo(song_id);


			System.out.println("COmposer name:"+composerAssoc.getComposer_Name());


			if(composerAssoc.getComposer_Name()==null)
			{
				System.out.println("******************************************");
				System.out.println("Details not found. ");
				System.out.println("******************************************");
			}
			else
			{
				System.out.println("******************************************");
				System.out.println(composerAssoc);
				System.out.println("******************************************");
			}
		}
		catch(Exception e)
		{
			e.getMessage();
		}
	}


	private static void FetchDetailsFromArtistAssoc()
	{

		artistAssoc= new Artist_Song_Assoc();
		System.out.println("Enter the song id: ");
		int song_id=sc.nextInt();

		System.out.println("song_id"+song_id);
		try 
		{
			medSer.getAllDetails(song_id);

			System.out.println("Artist name:"+artistAssoc.getArtist_Name());


			if(artistAssoc.getArtist_Name()==null)
			{
				System.out.println("******************************************");
				System.out.println("Details not found. ");
				System.out.println("******************************************");
			}
			else
			{
				System.out.println("******************************************");
				System.out.println(artistAssoc);
				System.out.println("******************************************");
			}
		}
		catch (MediaException e) 
		{

			e.printStackTrace();
		}


	}



	private static void addSongInComposerAssoc()
	{
		System.out.println(" Enter the Composer Id: ");
		int compId=sc.nextInt();
		try
		{
			if(medSer.validateComposerId(compId))
			{
				System.out.println(" Enter the Composer Name: ");
				String compName=sc.next();
				if(medSer.validateComposerName(compName))
				{

					System.out.println(" Enter the Song Id: ");
					int songId=sc.nextInt();
					if(medSer.validateSongId(songId))
					{

						System.out.println(" Enter the Song Name: ");
						String songName=sc.next();
						if(medSer.validateSongName(songName))
						{

							System.out.println(" Created By: ");
							int createdby=sc.nextInt();

							System.out.println(" Updated by: ");
							int updatedby=sc.nextInt();

							Composer_Song_Assoc csa=new Composer_Song_Assoc();
							csa.setComposer_Id(compId);
							csa.setComposer_Name(compName);
							csa.setSong_id(songId);
							csa.setSong_name(songName);
							csa.setCreated_by(createdby);
							csa.setUpdated_by(updatedby);

							try
							{
								int dataAdded=medSer.addSongIntoCompAssoc(csa);

								if(dataAdded==1)
								{
									System.out.println("******************************************");
									System.out.println("Data Added successfully with song Id: "+csa.getSong_id());
									System.out.println("******************************************");
								}
								else
								{
									System.out.println("******************************************");
									System.out.println("Data couldnt be added");
									System.out.println("******************************************");
								}
							}
							catch(Exception e)
							{
								e.getMessage();
							}
						}

						else
						{
							throw new MediaException("song name not valid");
						}
					}
					else
					{
						throw new MediaException("song Id already present in song Master table");
					}
				}
				else
				{
					throw new MediaException("composer name not valid");
				}
			}
			else
			{
				throw new MediaException("composer Id not present in composer master table");
			}
		}
		catch(Exception e)
		{
			System.err.println(e.getMessage());
		}
	}



	private static void addSongInArtistAssoc()
	{
		System.out.println(" Enter the artist Id: ");
		int artId=sc.nextInt();
		try
		{
			if(medSer.validateArtistId(artId))
			{
				System.out.println(" Enter the artist Name: ");
				String artName=sc.next();

				if(medSer.validateArtistName(artName))
				{

					System.out.println(" Enter the song Id: ");
					int songId=sc.nextInt();
					if(medSer.validateSongId(songId))
					{

						System.out.println(" Enter the song Name: ");
						String songName=sc.next();
						if(medSer.validateSongName(songName))
						{

							System.out.println(" Created By: ");
							int createdby=sc.nextInt();

							System.out.println(" Updated by: ");
							int updatedby=sc.nextInt();

							Artist_Song_Assoc asa=new Artist_Song_Assoc();
							asa.setArtist_Id(artId);
							asa.setArtist_Name(artName);
							asa.setSong_id(songId);
							asa.setSong_Name(songName);
							asa.setCreated_by(createdby);
							asa.setUpdated_by(updatedby);

							try
							{
								int dataAdded=medSer.addSongIntoArtAssoc(asa);

								if(dataAdded==1)
								{
									System.out.println("******************************************************************");
									System.out.println("Data Added successfully with song Id: "+asa.getSong_id());
									System.out.println("*******************************************************************");
								}
								else
								{
									System.out.println("******************************************");
									System.out.println("Data couldnt be added");
									System.out.println("******************************************");
								}
							}
							catch(Exception e)
							{
								System.err.println(e.getMessage());
							}
						}
						else
						{
							throw new MediaException("Song Name Not Valid");
						}
					}
					else
					{
						throw new MediaException("Song Id already present");
					}
				}
				else
				{
					throw new MediaException("Artist name not valid");
				}
			}
			else
			{
				throw new MediaException("Artist Id not present in artist master table");
			}
		}
		catch(Exception e)
		{
			System.err.println(e.getMessage());
		}
	}



	private static void updateArtist() 
	{
		System.out.println(" Enter the Artist ID: ");
		int artid=sc.nextInt();
		try 
		{
			if(medSer.validateArtistId(artid))
			{
				System.out.println("Enter Artist Name");
				String aname = sc.next();
				if(medSer.validateArtistName(aname))
				{

					System.out.println("Enter Artist Born Date (yyyy-mm-dd)");
					String adate= sc.next();
					if(medSer.validateArtistBirthDate(adate))
					{
						System.out.println("Enter Artist type ");
						String atype=sc.next();
						if(medSer.validateArtistType(atype))
						{

							Artist_Master am = new Artist_Master();
							am.setArtist_Name(aname);
							am.setArtist_Born_Date(adate);
							am.setArtist_Type(atype);

							int artUpdated=0;
							try 
							{
								artUpdated = medSer.updateArtist(artid,am);
							}
							catch (MediaException e) {

								e.printStackTrace();
							}

							if(artUpdated==1)
							{
								System.out.println("******************************************");
								System.out.println("Artist Succesfully Updated");
								System.out.println("******************************************");
							}
							else
							{
								System.out.println("******************************************");
								System.out.println("Some error occured while updating");
								System.out.println("******************************************");
							}
						}
						else
						{
							throw new MediaException("Artist Type not valid");
						}
					} 
					else
					{
						throw new MediaException("Artist Birth date Not Valid");
					}
				}
				else
				{
					throw new MediaException("Artist Name Not Valid");
				}
			}
			else
			{
				throw new MediaException("Artist Id not present in artist master table");
			}
		}
		catch (MediaException e) 
		{
			// TODO Auto-generated catch block
			System.err.println(e.getMessage());
		}
	}



	private static void updateComposer() 
	{
		System.out.println(" Enter the Composer ID: ");
		int comid=sc.nextInt();
		try 
		{
			if(medSer.validateComposerId(comid))
			{
				System.out.println("Enter Composer Name");
				String cname = sc.next();
				if(medSer.validateComposerName(cname))
				{
					System.out.println("Enter Composer Born Date (yyyy-mm-dd) ");
					String cdate= sc.next();
					if(medSer.validateComposerBirthDate(cdate))
					{
						System.out.println("Enter Composer caeipi number ([A-Z][0-9])");
						String num=sc.next();

						Composer_Master cm = new Composer_Master();
						cm.setComposer_Name(cname);
						cm.setComposer_Born_Date(cdate);
						cm.setComposer_Caeipi_Number(num);

						int comUpdated=0;
						try 
						{
							comUpdated = medSer.updateComposer(comid,cm);
						}
						catch (MediaException e) {

							e.printStackTrace();
						}

						if(comUpdated==1)
						{
							System.out.println("******************************************");
							System.out.println("Composer Succesfully Updated");
							System.out.println("******************************************");
						}
						else
						{
							System.out.println("******************************************");
							System.out.println("Some error occured while updating");
							System.out.println("******************************************");
						}

					}
					else
					{
						throw new MediaException("Composer Birth date Not Valid");
					}
				}
				else
				{
					throw new MediaException("Composer name not valid");
				}

			}
			else
			{
				throw new MediaException("Composer Id not present in ComposerMaster table");
			}
		}
		catch (MediaException e) 
		{
			// TODO Auto-generated catch block
			System.err.println(e.getMessage());
		}
	}



	/*****************************************ADD COMPOSER**************************************************/
	private static void AddComposer()
	{
		System.out.println(" Enter the Composer Name : ");
		String composerName=sc.next();
		try
		{
			if(medSer.validateComposerName(composerName))
			{
				System.out.println(" Enter the Composer Birth Date : (yyyy-mm-dd) ");
				String composerBirthDate=sc.next();
				if(medSer.validateComposerBirthDate(composerBirthDate))
				{
					System.out.println("Enter the Composer Caeipi Number: ([A-Z][0-9])");
					String ComposerCaNo=sc.next();

					System.out.println(" Created By: ");
					int createdBy=sc.nextInt();

					System.out.println(" Updated By: ");
					int updatedBy=sc.nextInt();


					Composer_Master cm=new Composer_Master();
					cm.setComposer_Name(composerName);
					cm.setComposer_Born_Date(composerBirthDate);
					cm.setComposer_Caeipi_Number(ComposerCaNo);
					cm.setCreated_by(createdBy);
					cm.setUpdated_by(updatedBy);

					int composerAdded=medSer.addComposer(cm);

					if(composerAdded>0)
					{
						System.out.println("******************************************");
						System.out.println("Composer Added successfully with Composer Id : "+composerAdded);
						System.out.println("******************************************");
					}
					else
					{
						System.out.println("******************************************");
						System.out.println("Composer couldnt be added");
						System.out.println("******************************************");
					}

				}
			}
		}
		catch(Exception e)
		{
			System.err.println(e.getMessage());
		}
	}	



	/*********************************************** ADD ARTIST****************************************************/

	private static void AddArtist() 
	{
		System.out.println(" Enter the Artist Name : ");
		String artistName=sc.next();
		try
		{
			if(medSer.validateArtistName(artistName))
			{
				System.out.println("Enter the Artist Type : [M(Male),F(Female)]");
				String artistType=sc.next();

				if(medSer.validateArtistType(artistType))
				{
					System.out.println(" Enter the Artist Birth Date : (yyyy-mm-dd)");
					String artistBirthDate=sc.next();
					if(medSer.validateArtistBirthDate(artistBirthDate))

					{

						System.out.println(" Created By: ");
						int createdBy=sc.nextInt();

						System.out.println(" Updated By: ");
						int updatedBy=sc.nextInt();


						Artist_Master am=new Artist_Master();
						am.setArtist_Name(artistName);
						am.setArtist_Type(artistType);
						am.setArtist_Born_Date(artistBirthDate);
						am.setCreated_By(createdBy);
						am.setUpdated_By(updatedBy);

						int artistAdded=medSer.addArtist(am);
						if(artistAdded>0)
						{
							System.out.println("******************************************");
							System.out.println("Artist Added successfully with Artist Id : "+artistAdded);
							System.out.println("******************************************");
						}
						else
						{
							System.out.println("******************************************");
							System.out.println("Artist couldnt be added");
							System.out.println("******************************************");
						}

					}
				}
			}
		}
		catch(Exception e)
		{
			System.err.println(e.getMessage());
		}

	}









	/***************************************************ADD SONGS* **********************************************/	

	private static void AddSongs() 
	{
		System.out.println(" Enter the Song Id: ");
		int songId=sc.nextInt();

		try
		{
			System.out.println("Enter the Artist Id:");
			int artId=sc.nextInt();

			if(medSer.validateArtistId(artId))
			{

				System.out.println("Enter Composer Id:");
				int compId=sc.nextInt();


				if(medSer.validateComposerId(compId))
				{
					System.out.println(" Enter the Song Name: ");
					String songName=sc.next();


					if(medSer.validateSongName(songName))
					{

						System.out.println(" Enter the song duration: ");
						String songDuration=sc.next();

						if(medSer.validateSongDuration(songDuration))
						{

							System.out.println(" Created By: ");
							int createdBy=sc.nextInt();

							System.out.println(" Updated By: ");
							int updatedBy=sc.nextInt();


							Song_Master sm=new Song_Master();
							sm.setSong_id(songId);
							sm.setArtist_id(artId);
							sm.setComposer_id(compId);
							sm.setSong_name(songName);
							sm.setSong_duration(songDuration);
							sm.setCreated_by(createdBy);
							sm.setUpdated_by(updatedBy);

							int songAdded=medSer.addSongs(sm);

							if(songAdded==1)
							{
								System.out.println("******************************************");
								System.out.println("Song Successfully Added with song Id:"+sm.getSong_id());
								System.out.println("******************************************");
							}
							else
							{
								System.out.println("******************************************");
								System.out.println("Some error occured while adding song");
								System.out.println("******************************************");
							}
						}
						else
						{
							throw new MediaException("song duration not properly given");
							//System.err.println("song duration not properly given");
						}
					}
					else
					{
						throw new MediaException("song name not properly given");
					}
				}
				else
				{
					throw new MediaException("composer Id not present");
				}
			}
			else
			{
				throw new MediaException("artist Id not present");
			}

		}
		catch(Exception e)
		{
			System.err.println(e.getMessage());
		}
	}

	/*************************************************** FIND SONG************************************************/
	private static void FindSong() 
	{
		Song_Master song= new Song_Master();
		System.out.println("Enter the song id: ");
		int song_id=sc.nextInt();

		if(song.getSong_name()==null)
		{
			System.out.println("******************************************");
			System.out.println("Details not found. ");
			System.out.println("******************************************");
		}
		else
		{
			System.out.println("******************************************");
			System.out.println(song);
			System.out.println("******************************************");
		}

	}

	/*****************************************FETCH ALL SONGS**********************************/

	private static void fetchAllSongs() 
	{
		try
		{
			ArrayList<Song_Master> songList=medSer.getAllSongs();
			System.out.println("Song_id\t\tSong_name\t\tSong_Duration\t");
			for(Song_Master sm:songList)
			{	
				//System.out.println("******************************************");

				System.out.println(sm);
				//System.out.println("******************************************");
			}
		}
		catch(Exception e)
		{
			System.out.println("******************************************");
			System.out.println("Some error while fetching");
			System.out.println("******************************************");
		}

	}




	/******************************************** FIND ARTIST********************************************/

	private static void findArtist()
	{

		Artist_Master artist= new Artist_Master();
		System.out.println("Enter the Artist Id: ");
		int artist_Id=sc.nextInt();

		if(artist.getArtist_Name()==null)
		{
			System.out.println("******************************************");
			System.out.println("Details not found. ");
			System.out.println("******************************************");
		}
		else
		{
			System.out.println("******************************************");
			System.out.println(artist);
			System.out.println("******************************************");
		}
	}


}
