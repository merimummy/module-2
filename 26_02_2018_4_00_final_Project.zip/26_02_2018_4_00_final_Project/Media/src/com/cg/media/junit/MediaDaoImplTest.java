package com.cg.media.junit;
import junit.framework.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.media.bean.Admin_Master;
import com.cg.media.bean.Artist_Master;
import com.cg.media.bean.Composer_Master;
import com.cg.media.bean.User_Master;
import com.cg.media.dao.MediaDao;
import com.cg.media.dao.MediaDaoImpl;
import com.cg.media.exception.MediaException;

public class MediaDaoImplTest 
{
	
	static MediaDao mDao=null;
	static Composer_Master comMaster=null;
	static Artist_Master artMaster=null;
	static int id=0;
	static User_Master user=null;
	static Admin_Master admin=null;
	
	@BeforeClass
	public static void beforeClass()
	{
		mDao=new MediaDaoImpl();
		comMaster=new Composer_Master();
		artMaster=new Artist_Master();
		id= artMaster.getArtist_Id();
		user= new User_Master();
		admin= new Admin_Master();
	}
	
	@Test
	public void testAddComposer1() throws MediaException
	{
		Assert.assertEquals(1, mDao.addComposer(comMaster));
	}
	
	@Test(expected=Exception.class)
	public void testAddComposer2() throws MediaException
	{
		Assert.assertEquals(1, mDao.addComposer(comMaster));
	}
	
	@Test
	public void testAddComposer3() throws MediaException
	{
		Assert.assertEquals(0, mDao.addComposer(comMaster));
	}
	
	@Test(expected=Exception.class)
	public void testAddComposer4() throws MediaException
	{
		Assert.assertEquals(0, mDao.addComposer(comMaster));
	}
	
	@Test
	public void testAddComposer5() throws MediaException
	{
		Assert.assertNotNull(mDao.addComposer(comMaster));
	}
	
	@Test(expected=Exception.class)
	public void testAddComposer6() throws MediaException
	{
		Assert.assertNotNull(mDao.addComposer(comMaster));
	}
	
	//************************************************
	
	@Test
	public void testEditArtist1() throws MediaException
	{
		Assert.assertEquals(1, mDao.updateArtist(id,artMaster));
	}
	
	@Test(expected=Exception.class)
	public void testEditArtist2() throws MediaException
	{
		Assert.assertEquals(1, mDao.updateArtist(id,artMaster));
	}
	
	@Test
	public void testEditArtist3() throws MediaException
	{
		Assert.assertEquals(0, mDao.updateArtist(id,artMaster));
	}
	
	@Test(expected=Exception.class)
	public void testEditArtist4() throws MediaException
	{
		Assert.assertEquals(0, mDao.updateArtist(id,artMaster));
	}
	
	@Test
	public void testEditArtist5() throws MediaException
	{
		Assert.assertNotNull(mDao.updateArtist(id,artMaster));
	}
	
	@Test(expected=Exception.class)
	public void testEditArtist6() throws MediaException
	{
		Assert.assertNotNull(mDao.updateArtist(id,artMaster));
	}
	
	//*****************************************************
	
	@Test
	public void testUserId1() throws MediaException
	{
		Assert.assertEquals(1001, mDao.getUserId());
	}
	
	@Test(expected=Exception.class)
	public void testUserId2() throws MediaException
	{
		Assert.assertEquals(1001, mDao.getUserId());
	}
	
	@Test
	public void testUserId3() throws MediaException
	{
		Assert.assertEquals(2001, mDao.getUserId());
	}
	
	@Test(expected=Exception.class)
	public void testUserId4() throws MediaException
	{
		Assert.assertEquals(0, mDao.getUserId());
	}
	
	@Test
	public void testUserId5() throws MediaException
	{
		Assert.assertNotNull(mDao.getUserId());
	}
	
	@Test(expected=Exception.class)
	public void testUserId6() throws MediaException
	{
		Assert.assertNotNull(mDao.getUserId());
	}
	
	//******************************************************
	
	@Test
	public void testAdminId1() throws MediaException
	{
		Assert.assertEquals(2002, mDao.getAdminId());
	}
	
	@Test(expected=Exception.class)
	public void testAdminId2() throws MediaException
	{
		Assert.assertEquals(2002, mDao.getAdminId());
	}
	
	@Test
	public void testAdminId3() throws MediaException
	{
		Assert.assertEquals(2001, mDao.getAdminId());
	}
	
	@Test(expected=Exception.class)
	public void testAdminId4() throws MediaException
	{
		Assert.assertEquals(0, mDao.getAdminId());
	}
	
	@Test
	public void testAdminId5() throws MediaException
	{
		Assert.assertNotNull(mDao.getAdminId());
	}
	
	@Test(expected=Exception.class)
	public void testAdminId6() throws MediaException
	{
		Assert.assertNotNull(mDao.getAdminId());
	}
	
	//*****************************************************
	
		@Test
		public void testUserPwd1() throws MediaException
		{
			Assert.assertEquals("user1001", mDao.getUserPwd());
		}
		
		@Test(expected=Exception.class)
		public void testUserPwd2() throws MediaException
		{
			Assert.assertEquals("abc", mDao.getUserPwd());
		}
		
		@Test
		public void testUserPwd3() throws MediaException
		{
			Assert.assertEquals("user1001", mDao.getUserPwd());
		}
		
		@Test(expected=Exception.class)
		public void testUserPwd4() throws MediaException
		{
			Assert.assertEquals(0, mDao.getUserPwd());
		}
		
		@Test
		public void testUserPwd5() throws MediaException
		{
			Assert.assertNotNull(mDao.getUserPwd());
		}
		
		@Test(expected=Exception.class)
		public void testUserPwd6() throws MediaException
		{
			Assert.assertNotNull(mDao.getUserPwd());
		}
		
		//*****************************************************
		
			@Test
			public void testAdminPwd1() throws MediaException
			{
				Assert.assertEquals("Admin2002", mDao.getAdminPwd());
			}
			
			@Test(expected=Exception.class)
			public void testAdminPwd2() throws MediaException
			{
				Assert.assertEquals("abc", mDao.getAdminPwd());
			}
			
			@Test
			public void testAdminPwd3() throws MediaException
			{
				Assert.assertEquals("admin", mDao.getAdminPwd());
			}
			
			@Test(expected=Exception.class)
			public void testAdminPwd4() throws MediaException
			{
				Assert.assertEquals(0, mDao.getAdminPwd());
			}
			
			@Test
			public void testAdminPwd5() throws MediaException
			{
				Assert.assertNotNull(mDao.getAdminPwd());
			}
			
			@Test(expected=Exception.class)
			public void testAdminPwd6() throws MediaException
			{
				Assert.assertNotNull(mDao.getAdminPwd());
			}
	
	
}
