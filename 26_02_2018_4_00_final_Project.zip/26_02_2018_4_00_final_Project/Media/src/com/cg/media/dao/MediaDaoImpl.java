package com.cg.media.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.media.bean.Artist_Master;
import com.cg.media.bean.Artist_Song_Assoc;
import com.cg.media.bean.Composer_Master;
import com.cg.media.bean.Composer_Song_Assoc;
import com.cg.media.bean.Song_Master;
import com.cg.media.exception.MediaException;
import com.cg.media.util.DBUtil;


public class MediaDaoImpl  implements MediaDao
{

	Connection con=null;
	Statement st=null;
	ResultSet rs=null;
	PreparedStatement pst=null;
	Logger mediaLogger=null;
	
	

	public MediaDaoImpl() 
	{
		PropertyConfigurator.configure("resources/log4j.properties");
		mediaLogger=Logger.getLogger("MediaDaoImpl.class");
	}

	/***************************************Add composer***********************************************************/
	@Override
	public int addComposer(Composer_Master cm) throws MediaException 
	{
		{
			String insertQry="Insert Into Composer_Master(composer_Id,composer_Name,composer_Born_Date,composer_Died_Date,composer_Caeipi_Number,Created_by,Created_on,Updated_by,Updated_on) Values(?,?,?,sysdate,?,?,sysdate,?,sysdate)";
			int composerAdded;
			try 
			{
				composerAdded=generateComposerId();
				con=DBUtil.getCon();
				pst=con.prepareStatement(insertQry);
				pst.setInt(1,composerAdded);
				pst.setString(2, cm.getComposer_Name());
				pst.setString(3, cm.getComposer_Born_Date());
				pst.setString(4, cm.getComposer_Caeipi_Number());
				pst.setInt(5,cm.getCreated_by());
				pst.setInt(6,cm.getUpdated_by());


				pst.executeUpdate();
				mediaLogger.log(Level.INFO,"Composer Data Inserted : "+cm);

			} 
			catch (Exception e) 
			{
				mediaLogger.error("This is Exception : "+e.getMessage());
				throw new MediaException(e.getMessage());
			} 
			finally
			{
				try 
				{
					pst.close();
					con.close();
				} 
				catch (SQLException e) 
				{
					mediaLogger.error("This is Exception : "+e.getMessage());
					throw new MediaException("Error while Inserting the Composer Data");
					
				}
			}

			return composerAdded;
		}

	}	

	/******************************************* Add Artist*********************************************************/
	@Override
	public int addArtist(Artist_Master am) throws MediaException 
	{

		{
			String insertQry="Insert Into Artist_Master(artist_Id,artist_Name,artist_Type,artist_Born_Date,artist_Died_Date,created_By,created_On,updated_By,updated_On) Values(?,?,?,?,sysdate,?,sysdate,?,sysdate)";
			int artistAdded;
			try 
			{
				artistAdded=generateArtistId();
			
				con=DBUtil.getCon();
				pst=con.prepareStatement(insertQry);
				pst.setInt(1,artistAdded);
				pst.setString(2, am.getArtist_Name());
				pst.setString(3, am.getArtist_Type());
				pst.setString(4,am.getArtist_Born_Date());
				pst.setInt(5,am.getCreated_By());
				pst.setInt(6, am.getUpdated_By());


				pst.executeUpdate();
				mediaLogger.log(Level.INFO,"Artist Data Inserted : "+am);

			} 
			catch (Exception e) 
			{
				e.printStackTrace();
				mediaLogger.error("This is Exception : "+e.getMessage());
				throw new MediaException(e.getMessage());
			} 
			finally
			{
				try 
				{
					pst.close();
					con.close();
				} 
				catch (SQLException e) 
				{
					mediaLogger.error("This is Exception : "+e.getMessage());
					throw new MediaException("Error while Inserting the Artist Data");
				}
			}

			return artistAdded;
		}

	}


	/******************************************* FIND COMPOSER***************************************************/

	@Override
	public Composer_Master getComposer(int composer_Id) throws MediaException 
	{
		String  selQry="SELECT * FROM composer_master where composer_id="+composer_Id;
		Composer_Master com=null;

		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(selQry);
			pst.setInt(1, composer_Id);
			rs=pst.executeQuery();
			while(rs.next())
			{
				com=new Composer_Master(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getDate(4),rs.getString(5),rs.getInt(6),rs.getDate(7),rs.getInt(8),rs.getDate(9));

			}
		}
		catch(Exception e)
		{
			throw new MediaException("Some error while fetching composer Details");
		}
		finally
		{
			try
			{
				con.close();
				st.close();
				rs.close();
			}
			catch(Exception e)
			{
				throw new MediaException("Some error while fetching composer Details");
			}
		}
		return com;
	}
	/***********************************************Find Artist*******************************************/

	@Override
	public Artist_Master getArtist(int artist_Id) throws MediaException 
	{

		String  selQry="SELECT * FROM Artist_master where artist_id="+artist_Id;
		Artist_Master am=null;

		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(selQry);
			pst.setInt(1, artist_Id);
			rs=pst.executeQuery();
			while(rs.next())
			{
				am=new Artist_Master(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getDate(5),rs.getInt(6),rs.getDate(7),rs.getInt(8),rs.getDate(9));

			}
		}
		catch(Exception e)
		{
			throw new MediaException("Some error while fetching Artist Details");
		}
		finally
		{
			try
			{
				con.close();
				st.close();
				rs.close();
			}
			catch(Exception e)
			{
				throw new MediaException("Some error while fetching Artist Details");
			}
		}
		return am;
	}



	/*********************************************ADD SONGS**************************************************/
	@Override
	public int addSongs(Song_Master sm) throws MediaException
	{
		{
			String insertQry="Insert Into Song_Master(song_id,artist_id,composer_id,song_name,song_duration,Created_by,Created_on,Updated_by,Updated_on) Values(?,?,?,?,?,?,sysdate,?,sysdate)";
			int songAdded=0;
			try 
			{
				con=DBUtil.getCon();
				pst=con.prepareStatement(insertQry);
				pst.setInt(1, sm.getSong_id());
				pst.setInt(2, sm.getArtist_id());
				pst.setInt(3, sm.getComposer_id());
				pst.setString(4, sm.getSong_name());
				pst.setString(5, sm.getSong_duration());
				pst.setInt(6, sm.getCreated_by());
				pst.setInt(7, sm.getUpdated_by());

				songAdded=pst.executeUpdate();
				mediaLogger.log(Level.INFO,"Song Data Inserted : "+sm);

			} 
			catch (Exception e) 
			{
				mediaLogger.error("This is Exception : "+e.getMessage());
				throw new MediaException("Already existing song Id OR Some error while Inserting Songs");
			} 
			finally
			{
				try 
				{
					pst.close();
					con.close();
				} 
				catch (SQLException e) 
				{
					mediaLogger.error("This is Exception : "+e.getMessage());
					throw new MediaException("Already existing song Id OR Some error while Inserting Songs");
				}
			}

			return songAdded;
		}
	}


	/*************************************************GET SONG FROM ID**********************************************/	
	@Override
	public Song_Master getSong(int song_id) throws MediaException 
	{
		String selquery="Select * from Song_Master where song_id= ? ";
		Song_Master song=null;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(selquery);
			pst.setInt(1, song_id);
			rs=pst.executeQuery();
			while(rs.next())
			{
				song=new Song_Master(rs.getInt(1),rs.getInt(2),rs.getInt(3),rs.getString(4),rs.getString(5),rs.getInt(6),rs.getDate(7),rs.getInt(8),rs.getDate(9));

			}
		}
		catch(Exception e)
		{
			throw new MediaException("Song Does not exist");
		}

		return song;


	}
	/******************************************************Fetch All songs*********************************************************/

	@Override
	public ArrayList<Song_Master> getAllSongs() throws MediaException
	{
		ArrayList<Song_Master> songList=new ArrayList<>();
		String selQuery="Select * from Song_Master";
		Song_Master sm=null;
		try
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selQuery);
			while(rs.next())
			{
				sm=new Song_Master(rs.getInt(1),rs.getInt(2),rs.getInt(3),rs.getString(4),rs.getString(5),rs.getInt(6),rs.getDate(7),rs.getInt(8),rs.getDate(9));
				songList.add(sm);
			}
		}
		catch(Exception e)
		{
			throw new MediaException("Some error while fetching all Songs");
		}
		finally
		{
			try
			{
				st.close();
				con.close();
				rs.close();
			}
			catch(Exception e)
			{
				throw new MediaException("Some error while fetching all Songs");
			}
		}
		return songList;
	}

	@Override
	public int updateComposer(int composer_id,Composer_Master cm) throws MediaException 
	{
		String query= "UPDATE Composer_Master SET composer_name=?,composer_born_date=?,composer_caeipi_number=? where composer_id=?";
		int dataUpdated=0;
		try
		{

			con=DBUtil.getCon();
			pst=con.prepareStatement(query);
			pst.setString(1,cm.getComposer_Name());
			pst.setString(2,cm.getComposer_Born_Date());
			pst.setString(3,cm.getComposer_Caeipi_Number());
			pst.setInt(4,composer_id);
			dataUpdated=pst.executeUpdate();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new MediaException("Some error while updating composer");
		}
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (Exception e) 
			{
				e.printStackTrace();
				throw new MediaException("Some error while updating composer");
			}
		}
		return dataUpdated;
	}


	@Override
	public int updateArtist(int artist_id,Artist_Master am) throws MediaException 
	{
		String query= "UPDATE Artist_Master SET artist_name=?,artist_born_date=?,artist_type=? where artist_id=?";
		int dataUpdated=0;
		try
		{

			con=DBUtil.getCon();
			pst=con.prepareStatement(query);
			pst.setString(1,am.getArtist_Name());
			pst.setString(2,am.getArtist_Born_Date());
			pst.setString(3,am.getArtist_Type());
			pst.setInt(4,artist_id);
			dataUpdated=pst.executeUpdate();
		}
		catch(Exception e)
		{
			throw new MediaException("Some error while updating artist");
		}
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (Exception e) 
			{
				throw new MediaException("Some error while updating artist");
			}
		}
		return dataUpdated ;
	}



	/*****************************************Generate SongsID****************************************************/	
	@Override
	public int generateSongId() throws MediaException 
	{
		String qry="Select songs_id.NextVal From Dual";

		int generatedSongsId;
		try 
		{

			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			rs.next();
			generatedSongsId=rs.getInt(1);

		} 

		catch (Exception e) 
		{

			throw new MediaException("Some error while Generating song Id");

		}

		finally
		{
			try
			{
				rs.close();
				st.close();
				con.close();
			} 

			catch (SQLException e) 
			{
				throw new MediaException("Some error while Generating song Id");
			}

		}

		return generatedSongsId;


	}


	/*****************************************Generate ComposerID****************************************************/	
	@Override
	public int generateComposerId() throws MediaException 
	{
		String qry="Select composer_id.NextVal From Dual";

		int generatedComposerId;
		try 
		{

			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			rs.next();
			generatedComposerId=rs.getInt(1);

		} 

		catch (Exception e) 
		{

			throw new MediaException("Some error while Generating composer Id");

		}

		finally
		{
			try
			{
				rs.close();
				st.close();
				con.close();
			} 

			catch (SQLException e) 
			{
				throw new MediaException("Some error while Generating composer Id");
			}

		}

		return generatedComposerId;

	}

	/*****************************************Generate Artist ID****************************************************/	

	@Override
	public int generateArtistId() throws MediaException 

	{
		String qry="Select artist_Id.NextVal From Dual";

		int generateArtistId;
		try 
		{

			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			rs.next();
			generateArtistId=rs.getInt(1);

		} 

		catch (Exception e) 
		{

			throw new MediaException("Some error while Generating artist Id");

		}

		finally
		{
			try
			{
				rs.close();
				st.close();
				con.close();
			} 

			catch (SQLException e) 
			{
				throw new MediaException("Some error while Generating artist Id");
			}

		}

		return generateArtistId;


	}





	/**************************************************login*************************************************/
	@Override
	public int getUserId() throws MediaException 
	{
		String selectQry="SELECT User_Id FROM User_Master";
		int id=0;
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			rs.next();
			id=rs.getInt(1);
		}
		catch (Exception e) 
		{
			throw new MediaException("Invalid user Id");
		}

		finally
		{
			try 
			{
				st.close();
				con.close();
				rs.close();
			}
			catch (SQLException e) 
			{
				throw new MediaException("Invalid user Id");
			}

		}
		return id;
	}

	@Override
	public String getUserPwd() throws MediaException 
	{
		String selectQry="SELECT User_Password FROM User_Master";

		String pwd;
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			rs.next();
			pwd=rs.getString(1);
		}
		catch (Exception e) 
		{
			throw new MediaException("Invalid user Password");
		}

		finally
		{
			try 
			{
				st.close();
				con.close();
				rs.close();
			}
			catch (SQLException e) 
			{
				throw new MediaException("Invalid user Password");
			}

		}
		return pwd;
	}

	@Override
	public int getAdminId() throws MediaException 
	{
		String selectQry="SELECT Admin_Id FROM Admin_Master";
		int id=0;
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			rs.next();
			id=rs.getInt(1);
		}
		catch (Exception e) 
		{
			throw new MediaException("Invalid Admin Id");
		}

		finally
		{
			try 
			{
				st.close();
				con.close();
				rs.close();
			}
			catch (SQLException e) 
			{
				throw new MediaException("Invalid Admin Id");
			}

		}
		return id;
	}

	@Override
	public String getAdminPwd() throws MediaException 
	{
		String selectQry="SELECT Admin_Password FROM Admin_Master";

		String pwd;
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			rs.next();
			pwd=rs.getString(1);
		}
		catch (Exception e) 
		{
			throw new MediaException("Invalid Admin Password");
		}

		finally
		{
			try 
			{
				st.close();
				con.close();
				rs.close();
			}
			catch (SQLException e) 
			{
				throw new MediaException("Invalid Admin Password");
			}

		}
		return pwd;
	}

	@Override
	public int addSongIntoArtAssoc(Artist_Song_Assoc asa) throws MediaException 
	{
		String insertQry="Insert Into Artist_Song_Assoc(artist_id,artist_Name,song_id,song_name,Created_by,Created_on,Updated_by,Updated_on) Values(?,?,?,?,?,sysdate,?,sysdate)";
		int dataAdded=0;
		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(insertQry);
			pst.setInt(1, asa.getArtist_Id());
			pst.setString(2, asa.getArtist_Name());
			pst.setInt(3, asa.getSong_id());
			pst.setString(4,asa.getSong_Name());
			pst.setInt(5, asa.getCreated_by());
			pst.setInt(6, asa.getUpdated_by());

			dataAdded=pst.executeUpdate();
			mediaLogger.log(Level.INFO,"Data Inserted : "+asa);

		} 
		catch (Exception e) 
		{
			mediaLogger.error("This is Exception : "+e.getMessage());
			throw new MediaException("Some error while inserting into artist song associate");
		} 
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				mediaLogger.error("This is Exception : "+e.getMessage());
				throw new MediaException("Some error while inserting into artist song associate");
			}
		}

		return dataAdded;
	}

	@Override
	public int addSongIntoCompAssoc(Composer_Song_Assoc csa) throws MediaException 
	{
		String insertQry="Insert Into Composer_Song_Assoc(composer_id,composer_Name,song_id,song_Name,Created_by,Created_on,Updated_by,Updated_on) Values(?,?,?,?,?,sysdate,?,sysdate)";
		int dataAdded=0;
		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(insertQry);
			pst.setInt(1, csa.getComposer_Id());
			pst.setString(2, csa.getComposer_Name());
			pst.setInt(3, csa.getSong_id());
			pst.setString(4, csa.getSong_name());
			pst.setInt(5, csa.getCreated_by());
			pst.setInt(6, csa.getUpdated_by());

			dataAdded=pst.executeUpdate();
			mediaLogger.log(Level.INFO,"Data Inserted : "+csa);

		} 
		catch (Exception e) 
		{
			mediaLogger.error("This is Exception : "+e.getMessage());
			throw new MediaException("Some error while inserting into composer song associate");
		} 
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				mediaLogger.error("This is Exception : "+e.getMessage());
				throw new MediaException("Some error while inserting into composer song associate");
			}
		}

		return dataAdded;
	}

	@Override
	public Artist_Song_Assoc getAllDetails(int song_id) throws MediaException 
	{

		String  selQry="SELECT * FROM Artist_Song_Assoc where song_id=?";
		Artist_Song_Assoc artistAssoc=null;

		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(selQry);
			pst.setInt(1, song_id);
			rs=pst.executeQuery();
			while(rs.next())
			{
				artistAssoc=new Artist_Song_Assoc(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getString(4),rs.getInt(5),rs.getDate(6),rs.getInt(7),rs.getDate(8));

			}
		}
		catch(Exception e)
		{
			throw new MediaException("Some error while fetching from artist song associate");
		}
		finally
		{
			try
			{
				con.close();
				st.close();
				rs.close();
			}
			catch(Exception e)
			{
				throw new MediaException("Some error while fetching from artist song associate");
			}
		}
		return artistAssoc;
	}

	
	@Override
	public Composer_Song_Assoc getAllInfo(int song_id) throws MediaException 
	{
		String  selQry="SELECT * FROM Composer_Song_Assoc where song_id=?";
		Composer_Song_Assoc composerAssoc=null;

		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(selQry);
			pst.setInt(1, song_id);
			rs=pst.executeQuery();
			while(rs.next())
			{
				composerAssoc=new Composer_Song_Assoc(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getString(4),rs.getInt(5),rs.getDate(6),rs.getInt(7),rs.getDate(8));

			}
		}
		catch(Exception e)
		{
			throw new MediaException("Some error while fetching from composer song associate");
		}
		finally
		{
			try
			{
				con.close();
				st.close();
				rs.close();
			}
			catch(Exception e)
			{
				throw new MediaException("Some error while fetching from composer song associate");
			}
		}
		return composerAssoc;
	}

	@Override
	public ArrayList<Integer> getComposerIds() throws MediaException 
	{
		ArrayList<Integer> comList=new ArrayList<Integer>();
		
		String selectQry="SELECT composer_id FROM composer_master";

		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			while(rs.next())
			{
				comList.add(rs.getInt("composer_id"));
			}
		}
		catch (Exception e) 
		{
			throw new MediaException("Error While getting all composer id");
		}
		
		finally
		{
			try 
			{
				st.close();
				con.close();
				rs.close();
			}
			catch (SQLException e) 
			{
				throw new MediaException(e.getMessage());
			}
			
		}
		return comList;

	}

	@Override
	public ArrayList<Integer> getArtistIds() throws MediaException 
	{
		ArrayList<Integer> artistList=new ArrayList<Integer>();
		
		String selectQry="SELECT artist_id FROM artist_master";

		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			while(rs.next())
			{
				artistList.add(rs.getInt("artist_id"));
			}
		}
		catch (Exception e) 
		{
			throw new MediaException("Error While getting all artist id");
		}
		
		finally
		{
			try 
			{
				st.close();
				con.close();
				rs.close();
			}
			catch (SQLException e) 
			{
				throw new MediaException(e.getMessage());
			}
			
		}
		return artistList;

	}

	@Override
	public ArrayList<Integer> getSongIds() throws MediaException 
	{
		ArrayList<Integer> songList=new ArrayList<Integer>();
		
		String selectQry="SELECT song_id FROM song_master";

		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			while(rs.next())
			{
				songList.add(rs.getInt("song_id"));
			}
		}
		catch (Exception e) 
		{
			throw new MediaException("Error While getting all song id");
		}
		
		finally
		{
			try 
			{
				st.close();
				con.close();
				rs.close();
			}
			catch (SQLException e) 
			{
				throw new MediaException(e.getMessage());
			}
			
		}
		return songList;

	}

	@Override
	public ArrayList<Integer> getArtistSongAssocIds() throws MediaException 
	{
		ArrayList<Integer> songArtList=new ArrayList<Integer>();
		
		String selectQry="SELECT song_id FROM artist_song_assoc";

		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			while(rs.next())
			{
				songArtList.add(rs.getInt("song_id"));
			}
		}
		catch (Exception e) 
		{
			throw new MediaException("Error While getting all song id from artist song associate table");
		}
		
		finally
		{
			try 
			{
				st.close();
				con.close();
				rs.close();
			}
			catch (SQLException e) 
			{
				throw new MediaException(e.getMessage());
			}
			
		}
		return songArtList;

	}

	@Override
	public ArrayList<Integer> getComposerSongAssocIds() throws MediaException 
	{
		ArrayList<Integer> songCompList=new ArrayList<Integer>();
		
		String selectQry="SELECT song_id FROM composer_song_assoc";

		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			while(rs.next())
			{
				songCompList.add(rs.getInt("song_id"));
			}
		}
		catch (Exception e) 
		{
			throw new MediaException("Error While getting all song id from composer song associate table");
		}
		
		finally
		{
			try 
			{
				st.close();
				con.close();
				rs.close();
			}
			catch (SQLException e) 
			{
				throw new MediaException(e.getMessage());
			}
			
		}
		return songCompList;


	}

}




