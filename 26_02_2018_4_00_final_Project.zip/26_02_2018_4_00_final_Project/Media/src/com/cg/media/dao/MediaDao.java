package com.cg.media.dao;

import java.util.ArrayList;

import com.cg.media.bean.Artist_Master;
import com.cg.media.bean.Artist_Song_Assoc;
import com.cg.media.bean.Composer_Master;
import com.cg.media.bean.Composer_Song_Assoc;
import com.cg.media.bean.Song_Master;
import com.cg.media.exception.MediaException;



public interface MediaDao 
{

	public int addComposer(Composer_Master cm) throws MediaException;
	public int addArtist(Artist_Master am) throws MediaException;
	public Composer_Master getComposer(int composer_Id) throws MediaException;
	public Artist_Master getArtist(int artist_Id) throws MediaException;
	public int addSongs(Song_Master sm) throws MediaException;
	public Song_Master getSong(int song_id) throws MediaException;
	
	public ArrayList<Song_Master> getAllSongs() throws MediaException;
	
	public int updateComposer(int composer_id,Composer_Master cm) throws MediaException;
	public int updateArtist(int artist_id,Artist_Master am) throws MediaException;
	public int addSongIntoArtAssoc(Artist_Song_Assoc asa) throws MediaException;
	public int addSongIntoCompAssoc(Composer_Song_Assoc csa) throws MediaException;
	
	public Artist_Song_Assoc getAllDetails(int song_id) throws MediaException;
	public Composer_Song_Assoc getAllInfo(int song_id) throws MediaException;

	
	
/**********************************Generate ID****************************************/
	
	public int generateSongId() throws MediaException;
	public int generateComposerId() throws MediaException;
	public int generateArtistId() throws MediaException;
	
	
/***************************************login***********************************************/
	
	public int getUserId() throws MediaException;
	
	public String getUserPwd() throws MediaException;
	
	public int getAdminId() throws MediaException;
	
	public String getAdminPwd() throws MediaException;
	
	/************************************Get Artist Name******************************/
	//public Artist_Master getAritstName(int artist_id) throws MediaException;
	public ArrayList<Integer> getComposerIds() throws MediaException;
	public ArrayList<Integer> getArtistIds() throws MediaException;
	public ArrayList<Integer> getSongIds() throws MediaException;
	public ArrayList<Integer> getArtistSongAssocIds() throws MediaException;
	public ArrayList<Integer> getComposerSongAssocIds() throws MediaException;
}
