package com.gear.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="query_master")
public class Gear {
	@Id
	@Column(name="query_id")
	private int queryId;
	@Column(name="technology",length=15)
	private String technology;
	@Column(name="query_raised_by",length=15)
	private String queryRaisedBy;
	@Column(name="query",length=15)
	private String query;
	@Column(name="solutions",length=15)
	@NotEmpty(message="Solution field should not kept blank")
	private String solutions;
	@Column(name="solution_given_by",length=15)

	private String solutionGivenBy;
	public Gear() {
		super();
	}
	public Gear(int queryId, String technology, String queryRaisedBy,
			String query, String solutions, String solutionGivenBy) {
		super();
		this.queryId = queryId;
		this.technology = technology;
		this.queryRaisedBy = queryRaisedBy;
		this.query = query;
		this.solutions = solutions;
		this.solutionGivenBy = solutionGivenBy;
	}
	public int getQueryId() {
		return queryId;
	}
	public void setQueryId(int queryId) {
		this.queryId = queryId;
	}
	public String getTechnology() {
		return technology;
	}
	public void setTechnology(String technology) {
		this.technology = technology;
	}
	public String getQueryRaisedBy() {
		return queryRaisedBy;
	}
	public void setQueryRaisedBy(String queryRaisedBy) {
		this.queryRaisedBy = queryRaisedBy;
	}
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}
	public String getSolutions() {
		return solutions;
	}
	public void setSolutions(String solutions) {
		this.solutions = solutions;
	}
	public String getSolutionGivenBy() {
		return solutionGivenBy;
	}
	public void setSolutionGivenBy(String solutionGivenBy) {
		this.solutionGivenBy = solutionGivenBy;
	}
	@Override
	public String toString() {
		return "Gear [queryId=" + queryId + ", technology=" + technology
				+ ", queryRaisedBy=" + queryRaisedBy + ", query=" + query
				+ ", solutions=" + solutions + ", solutionGivenBy="
				+ solutionGivenBy + "]";
	}
	
	
}

