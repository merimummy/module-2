package com.gear.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;



import com.gear.bean.Gear;
import com.gear.exception.GearException;
import com.gear.service.IGearService;

@Controller
public class GearController {

	@Autowired
	private IGearService gearservice;
	
	@RequestMapping(value="search",method=RequestMethod.GET)
	public String search(@RequestParam("queryId") int id,Model model) throws GearException
	{
		ModelAndView mv=new ModelAndView();
	//	try
	//	{
		if(gearservice.validateQueryId(id))
		{
			Gear g=new Gear();
			g.setQueryId(id);
			Gear myAllData1 = gearservice.view(id);
			model.addAttribute("gear",myAllData1);
			model.addAttribute("message", "Deleted");
			//model.setViewName("viewsucc");
			
			//mv.addObject("gear", myAllData1);
			//mv.setViewName("viewsucc");
			//return mv;
			return"viewsucc";
			}
		else
		{
			model.addAttribute("Id", id);
			return"error";
		}
		//} 
	//	catch (GearException e) 
		//{
		//	return new ModelAndView("error", "msg", e.getMessage());
		
		//}
		
	}
	
	
	@RequestMapping("updatedsuccessfully")
	public String success()
	{
		return "updatedsuccessfully";
	}
	
	@RequestMapping("update")
	public ModelAndView update(@ModelAttribute("gear") Gear gear){

		ModelAndView model=new ModelAndView();
		
		
		try {
			
			boolean isUpdated=gearservice.update(gear);
			model.setViewName("updatedsuccessfully");
			model.addObject("trainee", isUpdated);
			model.addObject("Gear",gear);
			
			
		} catch (GearException e) {
			model.setViewName("error");
			model.addObject("message","unable to update in dao layer"+e.getMessage());
		}
		return model;
		
	}
	
}
