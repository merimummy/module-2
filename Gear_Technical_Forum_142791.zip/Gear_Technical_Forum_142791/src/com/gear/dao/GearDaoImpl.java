package com.gear.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.gear.bean.Gear;
import com.gear.exception.GearException;

@Repository("gearDao")

public class GearDaoImpl implements IGearDao {
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public Gear view(int queryId) throws GearException 
	{
		Gear bean=new Gear();
		
		try 
		{
			String qry="select g from Gear g where g.queryId=:queryId";
			Query query=entityManager.createQuery(qry);
			query.setParameter("queryId", queryId);
			bean=(Gear) query.getSingleResult();
			
		} 
		catch (Exception e) 
		{
			throw new GearException("\n\n\n\nUnable to view in dao layer\n\n\n\n"+e.getMessage());
		}
		return bean;
	}

	@Override
	public boolean update(Gear gear) throws GearException 
	{
		boolean isUpdated=false;
		
		try 
		{
				entityManager.merge(gear);
				isUpdated=true;
		} 
		catch (Exception e) 
		{
			throw new GearException("Unable to update employee in dao layer"+e.getMessage());
		}
		
		return isUpdated;
	}

	@Override
	public List<Integer> getAllQueryId() 
	{
		String qry="select g.queryId from Gear g";
		Query query=entityManager.createQuery(qry);
		
		List<Integer> myList=query.getResultList();
		return myList;
	}

}
