package com.gear.service;

import java.util.List;

import com.gear.bean.Gear;
import com.gear.exception.GearException;

public interface IGearService {
	public Gear view(int queryId)throws GearException;
	
	public boolean update(Gear gear)throws GearException; 
	public List<Integer> getAllQueryId();
	
	public boolean validateQueryId(int queryId); 
}
