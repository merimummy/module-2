package com.cg.mobilepur.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.cg.mobilepur.exception.MobileException;
import com.cg.mobilepur.util.DBUtil;
import com.cg.mobilepur.bean.Mobile;
import com.cg.mobilepur.bean.MobilePurchase;


public class MobileDaoImpl implements MobileDao
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	Logger mobLogger=null;
	
	public MobileDaoImpl() 
	{
		PropertyConfigurator.configure("resources/log4j.properties");
		mobLogger=Logger.getLogger("MobileDaoImpl.class");
	}

	@Override
	public int addCustPurDetails(MobilePurchase mobPur) throws MobileException 
	{
		String insertQry="INSERT INTO purchasedetails VALUES(?,?,?,?,sysdate,?)";
		int dataAdded=0;
		try 
		{
			con=DBUtil.getCon();
			//System.out.println("******************"+con);
			pst=con.prepareStatement(insertQry);
			pst.setInt(1, generatePurchaseId());
			pst.setString(2, mobPur.getCustomerName());
			pst.setString(3, mobPur.getMailId());
			pst.setString(4, mobPur.getPhoneno());
			pst.setInt(5,mobPur.getMobileId());
			dataAdded=pst.executeUpdate();
			mobLogger.info("Customer PurchaseDetail Inserted :"+mobPur);
		}
		catch (Exception e)
		{
			mobLogger.error("This is Exception"+e.getMessage());
			throw new MobileException(e.getMessage());			
		} 
		finally
		{
			try 
			{
				pst.close();
				con.close();
			}
			catch (Exception e)
			{
				mobLogger.error("This is Exception"+e.getMessage());
				throw new MobileException(e.getMessage());
			}
		}
		return dataAdded;
	
	}

	@Override
	public int updateMobQuanty(int newQuantity,int mobileId) throws MobileException 
	{
		String updateQry="UPDATE  mobiles SET quantity=quantity-? WHERE mobileid=?";
		int dataUpdated=0;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(updateQry);
			pst.setInt(1,newQuantity);
			pst.setInt(2, mobileId);
			dataUpdated=pst.executeUpdate();
			//System.out.println("Hii"+dataUpdated);
			mobLogger.info(mobileId+"Mobile Quantity Updated ");
		} 
		catch (Exception e) 
		{	
			mobLogger.error("This is Exception related to mobile quantity Updation"+e.getMessage());
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e)
			{
				mobLogger.error("This is Exception related to mobile quantity Updation"+e.getMessage());
				throw new MobileException(e.getMessage());
			}
		}
		
		return dataUpdated;
	}

	@Override
	public ArrayList<Mobile> getAllMobileDetails() throws MobileException
	{
		
		ArrayList<Mobile> mobList=new ArrayList<Mobile>();
		String selectQry="SELECT * FROM mobiles";
		Mobile m=null;
		try 
		{			
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			while(rs.next())
			{
				m=new Mobile(rs.getInt("mobileid"),rs.getString("name"),rs.getFloat("price"),rs.getInt("quantity"));
				mobList.add(m);
				mobLogger.info("Mobiles Table Data Reterieved Successfully"+mobList);
			}
			
		} 
		catch (Exception e) 
		{	
			mobLogger.error("This is an Exception related to data reterieval"+e.getMessage());
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();
			} 
			catch (SQLException e)
			{
				mobLogger.error("This is an Exception related to data reterieval"+e.getMessage());
				throw new MobileException(e.getMessage());
			}
		}
		return mobList;
	}

	@Override
	public int deleteMobDetailById(int mobId) throws MobileException
	{
		
		String deleteQry="DELETE FROM  mobiles WHERE mobileid=?";
		int dataDeleted=0;
		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(deleteQry);
			pst.setInt(1, mobId);
			dataDeleted=pst.executeUpdate();
			mobLogger.info(mobId+" Data Deleted successfully ");
		} 
		catch (Exception e) 
		{	
			mobLogger.error("This is an Exception related to deletion"+e.getMessage());
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e)
			{
				mobLogger.error("This is an Exception related to deletion"+e.getMessage());
				throw new MobileException(e.getMessage());
			}
		}
		return dataDeleted;
	}

	@Override
	public ArrayList<Mobile> getMobDetailsByPrice(float minprice,float maxprice)
			throws MobileException 
	{
		ArrayList<Mobile> mobList=new ArrayList<Mobile>();
		String selectRangeQuery="SELECT * FROM mobiles WHERE price between ? and ? ";
		
		Mobile mob=null;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(selectRangeQuery);
			pst.setFloat(1, minprice);
			pst.setFloat(2, maxprice);
			rs=pst.executeQuery();
			
			while(rs.next())
			{		
				mob=new Mobile(rs.getInt("mobileid"),rs.getString("name"),rs.getFloat("price"),rs.getInt("quantity"));
				mobList.add(mob);
				//System.out.println("Hii"+mobList);
				mobLogger.info(" Data Fetched based on price Successfully  "+mobList);
			}
			
		} 
		catch (Exception e) 
		{
			mobLogger.error("This is an Exception related to search based on price"+e.getMessage());
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				pst.close();
				con.close();
			} 
			catch (SQLException e)
			{	
				mobLogger.error("This is an Exception related to search based on price"+e.getMessage());
				throw new MobileException(e.getMessage());
			}
		}
		//System.out.println("Hii2 "+mobList);
		
		return mobList;
	}

	@Override
	public int generatePurchaseId() throws MobileException 
	{
		String qry="Select pur_seq.NEXTVAL FROM DUAL";
		int generatedVal=0;
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			rs.next();
			generatedVal=rs.getInt(1);
			mobLogger.info(" Purchase Id generated successfully  "+generatedVal);
		}
		catch (Exception e) 
		{
			mobLogger.error("This is an Exception related to genearte Purchase Id"+e.getMessage());
			throw new MobileException(e.getMessage());
		} 
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();
			} 
			catch (SQLException e)
			{
				mobLogger.error("This is an Exception related to genearte Purchase Id"+e.getMessage());
				throw new MobileException(e.getMessage());
			}
		}
		return generatedVal;
	}

	@Override
	public ArrayList<Integer> getAllMobileId() throws MobileException 
	{
		ArrayList<Integer> mobList=new ArrayList<Integer>();
		String selectMobIdQry="SELECT mobileid FROM mobiles";
		Integer mId=0;
		try 
		{			
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectMobIdQry);
			while(rs.next())
			{				
				mId=rs.getInt("mobileId");
				mobList.add(mId);
				mobLogger.info(" MobileId Feteched Successuly  "+mobList);
			}
		} 
		catch (Exception e) 
		{	
			mobLogger.error("This is an Exception related to fetch MobileId"+e.getMessage());
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();
			} 
			catch (SQLException e)
			{
				mobLogger.error("This is an Exception related to fetch MobileId"+e.getMessage());
				throw new MobileException(e.getMessage());
			}
		}
		return mobList;
		
	}

	@Override
	public int getMobileQuanty(int mobId) throws MobileException
	{		
		String selectMobQuantyQry="SELECT quantity FROM mobiles WHERE mobileId=?";
	
		int mobQuan=0;
		try 
		{			
			con=DBUtil.getCon();
			pst=con.prepareStatement(selectMobQuantyQry);
			pst.setInt(1, mobId);
			rs=pst.executeQuery();
			rs.next();
			
			mobQuan=rs.getInt("quantity");
			mobLogger.info(" Mobile Quantity Feteched Successuly  "+mobQuan);
			//System.out.println("Hii 1"+mobQuan);
			
		} 
		catch (Exception e) 
		{
			mobLogger.error("This is an Exception related to fetch Mobile Quantity"+e.getMessage());

			throw new MobileException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				pst.close();
				con.close();
			} 
			catch (SQLException e)
			{
				mobLogger.error("This is an Exception related to fetch Mobile Quantity"+e.getMessage());

				throw new MobileException(e.getMessage());
			}
		}
		return mobQuan;
	}
	
}
