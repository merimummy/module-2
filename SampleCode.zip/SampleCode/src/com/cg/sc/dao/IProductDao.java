package com.cg.sc.dao;

import java.util.List;

import com.cg.sc.dto.Product;

public interface IProductDao
{
	List<Product> getAllProduct();
	public void updateProductById(Product product);
	public Product fetchProductById(int productId);
}
